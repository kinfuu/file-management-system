import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import Database from "better-sqlite3";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import multer from "multer";
import crypto from "crypto";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;
const JWT_SECRET = process.env.JWT_SECRET || "secure-fms-secret-key-123";
const UPLOADS_DIR = path.join(__dirname, "uploads");

// Ensure uploads directory exists
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Database Initialization
const db = new Database("fms.sqlite");
db.pragma("foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    name TEXT NOT NULL,
    father_name TEXT,
    grandfather_name TEXT,
    role TEXT CHECK(role IN ('super_admin', 'admin', 'employee')) NOT NULL DEFAULT 'employee',
    department TEXT,
    phone TEXT,
    must_change_password INTEGER DEFAULT 0,
    recovery_code TEXT DEFAULT 'RECOVERY123',
    deleted_at DATETIME DEFAULT NULL,
    deleted_by INTEGER DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS departments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    description TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS folders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    parent_id INTEGER,
    user_id INTEGER NOT NULL,
    department TEXT,
    is_locked INTEGER DEFAULT 0,
    lock_password TEXT,
    deleted_at DATETIME DEFAULT NULL,
    deleted_by INTEGER DEFAULT NULL,
    public_token TEXT UNIQUE DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_id) REFERENCES folders(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS files (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    original_name TEXT NOT NULL,
    mime_type TEXT,
    size INTEGER,
    hash TEXT,
    path TEXT NOT NULL,
    folder_id INTEGER,
    user_id INTEGER NOT NULL,
    department TEXT,
    description TEXT,
    status TEXT CHECK(status IN ('pending', 'approved', 'rejected')) NOT NULL DEFAULT 'pending',
    deleted_at DATETIME DEFAULT NULL,
    deleted_by INTEGER DEFAULT NULL,
    public_token TEXT UNIQUE DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (folder_id) REFERENCES folders(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS backup_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filename TEXT NOT NULL,
    size INTEGER NOT NULL,
    created_by INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS shares (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    item_type TEXT CHECK(item_type IN ('file', 'folder')) NOT NULL,
    item_id INTEGER NOT NULL,
    shared_by INTEGER NOT NULL,
    shared_with INTEGER NOT NULL,
    permission TEXT CHECK(permission IN ('view', 'edit')) NOT NULL DEFAULT 'view',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (shared_by) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (shared_with) REFERENCES users(id) ON DELETE CASCADE
  );
`);

// Migrations: Add missing columns if they don't exist
const tablesToMigrate = ["users", "files", "folders", "backup_logs", "shares"];
tablesToMigrate.forEach(tableName => {
  try {
    const tableInfo = db.prepare(`PRAGMA table_info(${tableName})`).all() as any[];
    const columns = tableInfo.map(col => col.name);
    console.log(`[MIGRATION] Table '${tableName}' columns:`, columns);

    const addColumn = (colName: string, type: string) => {
      if (!columns.includes(colName)) {
        try {
          db.exec(`ALTER TABLE ${tableName} ADD COLUMN ${colName} ${type}`);
          console.log(`[MIGRATION] Successfully added '${colName}' column to '${tableName}' table`);
        } catch (err: any) {
          console.error(`[MIGRATION] Failed to add '${colName}' to '${tableName}':`, err.message);
        }
      }
    };

    if (tableName !== "backup_logs") {
      addColumn("department", "TEXT");
      addColumn("deleted_at", "DATETIME DEFAULT NULL");
      addColumn("deleted_by", "INTEGER DEFAULT NULL");
    }

    if (tableName === "users") {
      addColumn("phone", "TEXT");
      addColumn("must_change_password", "INTEGER DEFAULT 0");
      addColumn("recovery_code", "TEXT DEFAULT 'RECOVERY123'");
      addColumn("father_name", "TEXT");
      addColumn("grandfather_name", "TEXT");
    }

    if (tableName === "files") {
      addColumn("hash", "TEXT");
    }

    if (tableName === "files" || tableName === "folders") {
      addColumn("public_token", "TEXT UNIQUE DEFAULT NULL");
    }

    if (tableName === "folders") {
      addColumn("is_locked", "INTEGER DEFAULT 0");
      addColumn("lock_password", "TEXT");
    }

    if (tableName === "files") {
      addColumn("description", "TEXT");
    }

    if (tableName === "backup_logs") {
      addColumn("created_by", "INTEGER DEFAULT NULL");
    }

    if (tableName === "shares") {
      addColumn("notified", "INTEGER DEFAULT 0");
    }
  } catch (err: any) {
    console.error(`[MIGRATION] Migration failed for table '${tableName}':`, err.message);
  }
});

// Seed Super Admin if not exists
const superAdminExists = db.prepare("SELECT * FROM users WHERE role = 'super_admin'").get();
if (!superAdminExists) {
  try {
    const hashedPassword = bcrypt.hashSync("superadmin@2024", 10);
    db.prepare("INSERT INTO users (email, password, name, role, department, must_change_password) VALUES (?, ?, ?, ?, ?, 1)").run(
      "superadmin@gmail.com",
      hashedPassword,
      "Super Administrator",
      "super_admin",
      "Management"
    );
    console.log("Default super admin created: superadmin@gmail.com / superadmin@2024");
  } catch (err: any) {
    if (err.message.includes("CHECK constraint failed")) {
      console.log("[MIGRATION] Recreating users table to support super_admin role...");
      db.exec(`
        CREATE TABLE users_new (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          email TEXT UNIQUE NOT NULL,
          password TEXT NOT NULL,
          name TEXT NOT NULL,
          role TEXT CHECK(role IN ('super_admin', 'admin', 'employee')) NOT NULL DEFAULT 'employee',
          department TEXT,
          phone TEXT,
          must_change_password INTEGER DEFAULT 0,
          recovery_code TEXT DEFAULT 'RECOVERY123',
          deleted_at DATETIME DEFAULT NULL,
          deleted_by INTEGER DEFAULT NULL,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        INSERT INTO users_new (id, email, password, name, role, department, phone, must_change_password, recovery_code, deleted_at, deleted_by, created_at)
        SELECT id, email, password, name, role, department, phone, must_change_password, 'RECOVERY123', deleted_at, deleted_by, created_at FROM users;
        DROP TABLE users;
        ALTER TABLE users_new RENAME TO users;
      `);
      const hashedPassword = bcrypt.hashSync("superadmin@2024", 10);
      db.prepare("INSERT INTO users (email, password, name, role, department, must_change_password) VALUES (?, ?, ?, ?, ?, 1)").run(
        "superadmin@gmail.com",
        hashedPassword,
        "Super Administrator",
        "super_admin",
        "Management"
      );
      console.log("Default super admin created after migration");
    }
  }
} else {
  // Force existing super admin to change password if they are using the old default
  const superAdmin: any = superAdminExists;
  if (bcrypt.compareSync("superadmin123", superAdmin.password)) {
    const newHashedPassword = bcrypt.hashSync("superadmin@2024", 10);
    db.prepare("UPDATE users SET password = ?, must_change_password = 1 WHERE id = ?").run(newHashedPassword, superAdmin.id);
  }
}

// Seed Admin if not exists
const adminExists = db.prepare("SELECT * FROM users WHERE role = 'admin'").get();
if (!adminExists) {
  const hashedPassword = bcrypt.hashSync("admin@2024", 10);
  db.prepare("INSERT INTO users (email, password, name, role, department, must_change_password) VALUES (?, ?, ?, ?, ?, 1)").run(
    "admin@gmail.com",
    hashedPassword,
    "System Admin",
    "admin",
    "IT"
  );
  console.log("Default admin created: admin@gmail.com / admin@2024");
} else {
  // Force existing admin to change password if they are using the old default
  const admin: any = adminExists;
  if (bcrypt.compareSync("admin123", admin.password)) {
    const newHashedPassword = bcrypt.hashSync("admin@2024", 10);
    db.prepare("UPDATE users SET password = ?, must_change_password = 1 WHERE id = ?").run(newHashedPassword, admin.id);
  }
}

const app = express();
app.use(express.json());

// Multer Configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + "-" + file.originalname);
  },
});
const upload = multer({ storage });

// Middleware: Auth
const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) return res.status(401).json({ error: "Access denied" });

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) return res.status(403).json({ error: "Invalid token" });
    req.user = user;
    next();
  });
};

const isAdmin = (req: any, res: any, next: any) => {
  if (req.user.role !== "admin" && req.user.role !== "super_admin") {
    return res.status(403).json({ error: "Admin access required" });
  }
  next();
};

const isSuperAdmin = (req: any, res: any, next: any) => {
  if (req.user.role !== "super_admin") {
    return res.status(403).json({ error: "Super Admin access required" });
  }
  next();
};

// --- AUTH ROUTES ---
app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body;
  const user: any = db.prepare("SELECT * FROM users WHERE email = ?").get(email);

  if (!user || !bcrypt.compareSync(password, user.password)) {
    return res.status(401).json({ error: "Invalid credentials" });
  }

  const token = jwt.sign({ 
    id: user.id, 
    email: user.email, 
    role: user.role, 
    name: user.name, 
    department: user.department,
    must_change_password: user.must_change_password
  }, JWT_SECRET, {
    expiresIn: "24h",
  });
  res.json({ 
    token, 
    user: { 
      id: user.id, 
      email: user.email, 
      role: user.role, 
      name: user.name, 
      department: user.department,
      must_change_password: user.must_change_password
    } 
  });
});

app.post("/api/auth/reset-password", (req, res) => {
  const { email, recovery_code, new_password } = req.body;
  
  if (!email || !recovery_code || !new_password) {
    return res.status(400).json({ error: "Email, recovery code, and new password are required" });
  }

  const user: any = db.prepare("SELECT * FROM users WHERE email = ? AND deleted_at IS NULL").get(email);

  if (!user) {
    return res.status(404).json({ error: "User not found" });
  }

  if (user.role !== "admin" && user.role !== "super_admin") {
    return res.status(403).json({ error: "Password reset is only available for administrators" });
  }

  if (user.recovery_code !== recovery_code) {
    return res.status(401).json({ error: "Invalid recovery code" });
  }

  const hashedPassword = bcrypt.hashSync(new_password, 10);
  db.prepare("UPDATE users SET password = ?, must_change_password = 0 WHERE id = ?").run(hashedPassword, user.id);

  res.json({ message: "Password reset successfully" });
});

app.post("/api/auth/change-password-forced", authenticateToken, (req: any, res) => {
  const { newPassword } = req.body;
  const userId = req.user.id;

  try {
    const hashedPassword = bcrypt.hashSync(newPassword, 10);
    db.prepare("UPDATE users SET password = ?, must_change_password = 0 WHERE id = ?").run(hashedPassword, userId);
    
    const user: any = db.prepare("SELECT * FROM users WHERE id = ?").get(userId);
    const token = jwt.sign({ 
      id: user.id, 
      email: user.email, 
      role: user.role, 
      name: user.name, 
      department: user.department,
      must_change_password: 0
    }, JWT_SECRET, {
      expiresIn: "24h",
    });

    res.json({ message: "Password updated successfully", token, user: {
      id: user.id,
      email: user.email,
      role: user.role,
      name: user.name,
      department: user.department,
      must_change_password: 0
    }});
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.get("/api/auth/me", authenticateToken, (req: any, res) => {
  const user: any = db.prepare("SELECT id, email, name, father_name, grandfather_name, role, department, phone, must_change_password, recovery_code FROM users WHERE id = ?").get(req.user.id);
  if (!user) return res.status(404).json({ error: "User not found" });
  res.json({ user });
});

app.put("/api/auth/profile", authenticateToken, (req: any, res) => {
  const { name, father_name, grandfather_name, phone, recovery_code } = req.body;
  const userId = req.user.id;

  try {
    db.prepare("UPDATE users SET name = COALESCE(?, name), father_name = COALESCE(?, father_name), grandfather_name = COALESCE(?, grandfather_name), phone = COALESCE(?, phone), recovery_code = COALESCE(?, recovery_code) WHERE id = ?").run(
      name || null,
      father_name || null,
      grandfather_name || null,
      phone || null,
      recovery_code || null,
      userId
    );
    res.json({ message: "Profile updated successfully" });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// --- USER ROUTES (Admin/SuperAdmin Only) ---
app.get("/api/users", authenticateToken, isAdmin, (req: any, res) => {
  const page = parseInt(req.query.page as string) || 1;
  const limit = parseInt(req.query.limit as string) || 10;
  const offset = (page - 1) * limit;

  let users;
  let total;

  if (req.user.role === "super_admin") {
    users = db.prepare("SELECT id, email, name, role, department, phone, created_at FROM users LIMIT ? OFFSET ?").all(limit, offset);
    total = db.prepare("SELECT COUNT(*) as count FROM users").get() as any;
  } else {
    // Admins can only see employees
    users = db.prepare("SELECT id, email, name, role, department, phone, created_at FROM users WHERE role = 'employee' LIMIT ? OFFSET ?").all(limit, offset);
    total = db.prepare("SELECT COUNT(*) as count FROM users WHERE role = 'employee'").get() as any;
  }
  
  res.json({ users, total: total.count, page, limit });
});

app.post("/api/users", authenticateToken, isAdmin, (req: any, res) => {
  const { email, password, name, father_name, grandfather_name, role, department, phone } = req.body;
  
  // Role restriction
  if (req.user.role === "admin" && (role === "admin" || role === "super_admin")) {
    return res.status(403).json({ error: "Admins can only create employees" });
  }

  // Validation
  const emailRegex = /^[^\s@]+@gmail\.com$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ error: "Invalid email format. Must be a @gmail.com address." });
  }

  const phoneRegex = /^\+251\d{9}$/;
  if (phone && !phoneRegex.test(phone)) {
    return res.status(400).json({ error: "Invalid phone format. Must be +251 followed by 9 digits." });
  }

  try {
    const hashedPassword = bcrypt.hashSync(password, 10);
    db.prepare("INSERT INTO users (email, password, name, father_name, grandfather_name, role, department, phone, must_change_password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)").run(
      email,
      hashedPassword,
      name,
      father_name || null,
      grandfather_name || null,
      role,
      department,
      phone
    );
    res.status(201).json({ message: "User created successfully" });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.put("/api/users/:id", authenticateToken, isAdmin, (req: any, res) => {
  const { email, name, father_name, grandfather_name, role, department, phone, password } = req.body;
  const { id } = req.params;

  // Role restriction
  const targetUser: any = db.prepare("SELECT role FROM users WHERE id = ?").get(id);
  if (!targetUser) return res.status(404).json({ error: "User not found" });

  if (req.user.role === "admin") {
    if (targetUser.role !== "employee" || (role && role !== "employee")) {
      return res.status(403).json({ error: "Admins can only manage employees" });
    }
  }

  // Validation
  if (email) {
    const emailRegex = /^[^\s@]+@gmail\.com$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ error: "Invalid email format. Must be a @gmail.com address." });
    }
  }

  const phoneRegex = /^\+251\d{9}$/;
  if (phone && !phoneRegex.test(phone)) {
    return res.status(400).json({ error: "Invalid phone format. Must be +251 followed by 9 digits." });
  }

  try {
    if (password) {
      const hashedPassword = bcrypt.hashSync(password, 10);
      db.prepare("UPDATE users SET email = ?, name = ?, father_name = ?, grandfather_name = ?, role = ?, department = ?, phone = ?, password = ? WHERE id = ?").run(
        email,
        name,
        father_name || null,
        grandfather_name || null,
        role,
        department,
        phone,
        hashedPassword,
        id
      );
    } else {
      db.prepare("UPDATE users SET email = ?, name = ?, father_name = ?, grandfather_name = ?, role = ?, department = ?, phone = ? WHERE id = ?").run(
        email,
        name,
        father_name || null,
        grandfather_name || null,
        role,
        department,
        phone,
        id
      );
    }
    res.json({ message: "User updated successfully" });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.post("/api/users/:id/reset-password", authenticateToken, isAdmin, (req: any, res) => {
  const { id } = req.params;
  const { newPassword } = req.body;

  if (!newPassword) {
    return res.status(400).json({ error: "New password is required" });
  }

  // Role restriction
  const targetUser: any = db.prepare("SELECT role FROM users WHERE id = ?").get(id);
  if (!targetUser) return res.status(404).json({ error: "User not found" });

  if (req.user.role === "admin" && targetUser.role !== "employee") {
    return res.status(403).json({ error: "Admins can only reset passwords for employees" });
  }

  try {
    const hashedPassword = bcrypt.hashSync(newPassword, 10);
    db.prepare("UPDATE users SET password = ?, must_change_password = 1 WHERE id = ?").run(hashedPassword, id);
    res.json({ message: "Password reset successfully. User will be forced to change it on next login." });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.delete("/api/users/:id", authenticateToken, isAdmin, (req: any, res) => {
  const { id } = req.params;

  // Role restriction
  const targetUser: any = db.prepare("SELECT role FROM users WHERE id = ?").get(id);
  if (!targetUser) return res.status(404).json({ error: "User not found" });

  if (req.user.role === "admin" && targetUser.role !== "employee") {
    return res.status(403).json({ error: "Admins can only delete employees" });
  }

  try {
    // 1. Find all files owned by this user and delete from disk
    const files = db.prepare("SELECT * FROM files WHERE user_id = ?").all(id) as any[];
    files.forEach(file => {
      if (fs.existsSync(file.path)) {
        try {
          fs.unlinkSync(file.path);
        } catch (err) {
          console.error(`Failed to delete file from disk: ${file.path}`, err);
        }
      }
    });

    // 2. Delete all files and folders owned by this user from DB
    db.prepare("DELETE FROM files WHERE user_id = ?").run(id);
    db.prepare("DELETE FROM folders WHERE user_id = ?").run(id);

    // 3. Delete the user
    db.prepare("DELETE FROM users WHERE id = ?").run(id);
    res.json({ message: "User and all their data deleted successfully" });
  } catch (error: any) {
    console.error(`Failed to delete user ${id}:`, error.message);
    res.status(500).json({ error: error.message });
  }
});

// --- DEPARTMENT ROUTES (SuperAdmin Only) ---
app.get("/api/departments", authenticateToken, (req, res) => {
  const depts = db.prepare("SELECT * FROM departments ORDER BY name ASC").all();
  res.json({ departments: depts });
});

app.post("/api/departments", authenticateToken, isSuperAdmin, (req, res) => {
  const { name, description } = req.body;
  try {
    db.prepare("INSERT INTO departments (name, description) VALUES (?, ?)").run(name, description);
    res.status(201).json({ message: "Department created successfully" });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.put("/api/departments/:id", authenticateToken, isSuperAdmin, (req, res) => {
  const { id } = req.params;
  const { name, description } = req.body;
  try {
    db.prepare("UPDATE departments SET name = ?, description = ? WHERE id = ?").run(name, description, id);
    res.json({ message: "Department updated successfully" });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.delete("/api/departments/:id", authenticateToken, isSuperAdmin, (req, res) => {
  const { id } = req.params;
  try {
    db.prepare("DELETE FROM departments WHERE id = ?").run(id);
    res.json({ message: "Department deleted successfully" });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

// --- FOLDER ROUTES ---
app.get("/api/folders", authenticateToken, (req: any, res) => {
  const { parentId } = req.query;
  const page = parseInt(req.query.page as string) || 1;
  const limit = parseInt(req.query.limit as string) || 10;
  const offset = (page - 1) * limit;

  const pId = (parentId && parentId !== "" && parentId !== "null" && parentId !== "undefined") ? parentId : null;
  console.log(`Fetching folders for parentId: ${pId}, user: ${req.user.email}, role: ${req.user.role}, page: ${page}`);
  
  let folders;
  let total;
  try {
    if (req.user.role === "super_admin") {
      let where = ["f.deleted_at IS NULL"];
      let params: any[] = [];
      
      if (pId) {
        // Check if user has access to the parent folder
        const parentFolder: any = db.prepare("SELECT user_id FROM folders WHERE id = ?").get(pId);
        if (!parentFolder) return res.status(404).json({ error: "Parent folder not found" });

        const isShared = db.prepare("SELECT 1 FROM shares WHERE item_type = 'folder' AND item_id = ? AND shared_with = ?").get(pId, req.user.id);
        
        // Check if any ancestor is shared
        const isAncestorShared = db.prepare(`
          WITH RECURSIVE ancestors(id, parent_id) AS (
            SELECT id, parent_id FROM folders WHERE id = ?
            UNION ALL
            SELECT f.id, f.parent_id FROM folders f JOIN ancestors ON f.id = ancestors.parent_id
          )
          SELECT 1 FROM ancestors a JOIN shares s ON s.item_id = a.id WHERE s.item_type = 'folder' AND s.shared_with = ?
        `).get(pId, req.user.id);

        if (Number(parentFolder.user_id) !== Number(req.user.id) && !isShared && !isAncestorShared) {
          return res.status(403).json({ error: "Unauthorized access to this folder" });
        }

        where.push("f.parent_id = ?");
        params.push(pId);
      } else {
        where.push("f.parent_id IS NULL");
        where.push(`(
          f.user_id = ? 
          OR EXISTS (SELECT 1 FROM shares s WHERE s.item_type = 'folder' AND s.item_id = f.id AND s.shared_with = ?)
        )`);
        params.push(req.user.id, req.user.id);
      }
      
      const whereSql = " WHERE " + where.join(" AND ");
      const query = `FROM folders f LEFT JOIN users u ON f.user_id = u.id ${whereSql}`;

      folders = db.prepare(`SELECT f.*, COALESCE(f.department, u.department) as department ${query} LIMIT ? OFFSET ?`).all(...params, limit, offset);
      total = db.prepare(`SELECT COUNT(*) as count ${query}`).get(...params) as any;
    } else {
      // Private by default + Sharing (for employees and admins)
      const where = ["f.deleted_at IS NULL", "u.role != 'super_admin'"];
      const params: any[] = [];

      if (pId) {
        // Check if user has access to the parent folder
        const parentFolder: any = db.prepare("SELECT user_id FROM folders WHERE id = ?").get(pId);
        if (!parentFolder) return res.status(404).json({ error: "Parent folder not found" });

        const isShared = db.prepare("SELECT 1 FROM shares WHERE item_type = 'folder' AND item_id = ? AND shared_with = ?").get(pId, req.user.id);
        
        // Check if any ancestor is shared
        const isAncestorShared = db.prepare(`
          WITH RECURSIVE ancestors(id, parent_id) AS (
            SELECT id, parent_id FROM folders WHERE id = ?
            UNION ALL
            SELECT f.id, f.parent_id FROM folders f JOIN ancestors ON f.id = ancestors.parent_id
          )
          SELECT 1 FROM ancestors a JOIN shares s ON s.item_id = a.id WHERE s.item_type = 'folder' AND s.shared_with = ?
        `).get(pId, req.user.id);

        if (Number(parentFolder.user_id) !== Number(req.user.id) && !isShared && !isAncestorShared) {
          return res.status(403).json({ error: "Unauthorized access to this folder" });
        }

        where.push("f.parent_id = ?");
        params.push(pId);
      } else {
        where.push("f.parent_id IS NULL");
        where.push(`(
          f.user_id = ? 
          OR EXISTS (SELECT 1 FROM shares s WHERE s.item_type = 'folder' AND s.item_id = f.id AND s.shared_with = ?)
        )`);
        params.push(req.user.id, req.user.id);
      }

      const whereSql = " WHERE " + where.join(" AND ");
      const query = `FROM folders f LEFT JOIN users u ON f.user_id = u.id ${whereSql}`;

      folders = db.prepare(`SELECT f.*, COALESCE(f.department, u.department) as department ${query} LIMIT ? OFFSET ?`).all(...params, limit, offset);
      total = db.prepare(`SELECT COUNT(*) as count ${query}`).get(...params) as any;
    }
    res.json({ folders, total: total.count, page, limit });
  } catch (error: any) {
    console.error("Failed to fetch folders:", error.message);
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/folders", authenticateToken, (req: any, res) => {
  const { name, parentId, password } = req.body;
  const pId = (parentId && parentId !== "" && parentId !== "null") ? parentId : null;
  
  try {
    // Check for duplication
    const existing = db.prepare("SELECT id FROM folders WHERE name = ? AND parent_id IS ? AND user_id = ? AND deleted_at IS NULL")
      .get(name, pId, req.user.id);
    
    if (existing) {
      return res.status(400).json({ error: "A folder with this name already exists in this location" });
    }

    const isLocked = password ? 1 : 0;
    const hashedPassword = password ? bcrypt.hashSync(password, 10) : null;

    db.prepare("INSERT INTO folders (name, parent_id, user_id, department, is_locked, lock_password) VALUES (?, ?, ?, ?, ?, ?)").run(
      name,
      pId,
      req.user.id,
      req.user.department || null,
      isLocked,
      hashedPassword
    );
    res.status(201).json({ message: "Folder created successfully" });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.put("/api/folders/:id", authenticateToken, (req: any, res) => {
  const { id } = req.params;
  const { name } = req.body;
  const folder: any = db.prepare("SELECT f.*, u.role as owner_role FROM folders f JOIN users u ON f.user_id = u.id WHERE f.id = ?").get(id);
  if (!folder) return res.status(404).json({ error: "Folder not found" });
  
  const isSuper = req.user.role === "super_admin";
  const isAdminRole = req.user.role === "admin";
  const isOwner = Number(folder.user_id) === Number(req.user.id);
  
  if (!isSuper) {
    if (isAdminRole) {
      if (folder.owner_role === "super_admin") return res.status(403).json({ error: "Unauthorized" });
    } else {
      if (!isOwner) return res.status(403).json({ error: "Unauthorized" });
    }
  }
  db.prepare("UPDATE folders SET name = ? WHERE id = ?").run(name, id);
  res.json({ message: "Folder updated successfully" });
});

app.post("/api/folders/:id/lock", authenticateToken, (req: any, res) => {
  const { id } = req.params;
  const { password } = req.body;
  const folder: any = db.prepare("SELECT * FROM folders WHERE id = ?").get(id);
  
  if (!folder) return res.status(404).json({ error: "Folder not found" });
  if (Number(folder.user_id) !== Number(req.user.id) && req.user.role !== "super_admin") {
    return res.status(403).json({ error: "Only the owner can lock this folder" });
  }

  const hashedPassword = password ? bcrypt.hashSync(password, 10) : null;
  db.prepare("UPDATE folders SET is_locked = 1, lock_password = ? WHERE id = ?").run(hashedPassword, id);
  res.json({ message: "Folder locked successfully" });
});

app.post("/api/folders/:id/unlock", authenticateToken, (req: any, res) => {
  const { id } = req.params;
  const { password } = req.body;
  const folder: any = db.prepare("SELECT * FROM folders WHERE id = ?").get(id);
  
  if (!folder) return res.status(404).json({ error: "Folder not found" });
  
  const isAuthorized = Number(folder.user_id) === Number(req.user.id) || req.user.role === "super_admin";
  
  if (!isAuthorized) {
    return res.status(403).json({ error: "Only the owner can unlock this folder" });
  }

  if (folder.lock_password) {
    if (!password) {
      return res.status(401).json({ error: "Password required to unlock this folder" });
    }
    if (!bcrypt.compareSync(password, folder.lock_password)) {
      return res.status(401).json({ error: "Invalid password" });
    }
  }

  db.prepare("UPDATE folders SET is_locked = 0, lock_password = NULL WHERE id = ?").run(id);
  res.json({ message: "Folder unlocked successfully" });
});

app.post("/api/folders/:id/verify-lock", authenticateToken, (req: any, res) => {
  const { id } = req.params;
  const { password } = req.body;
  const folder: any = db.prepare("SELECT * FROM folders WHERE id = ?").get(id);
  
  if (!folder) return res.status(404).json({ error: "Folder not found" });
  if (!folder.is_locked) return res.json({ message: "Not locked" });

  const isAuthorized = Number(folder.user_id) === Number(req.user.id) || req.user.role === "super_admin";
  
  if (!isAuthorized) {
    return res.status(403).json({ error: "This folder is private and locked by the owner" });
  }

  if (folder.lock_password) {
    if (!password) {
      return res.status(401).json({ error: "Password required to access this folder" });
    }
    if (!bcrypt.compareSync(password, folder.lock_password)) {
      return res.status(401).json({ error: "Invalid password" });
    }
  }

  res.json({ message: "Access granted" });
});

// --- FILE ROUTES ---
app.get("/api/files", authenticateToken, (req: any, res) => {
  const { folderId, status } = req.query;
  const page = parseInt(req.query.page as string) || 1;
  const limit = parseInt(req.query.limit as string) || 10;
  const offset = (page - 1) * limit;

  const fId = (folderId && folderId !== "" && folderId !== "null" && folderId !== "undefined") ? folderId : null;
  console.log(`Fetching files for folderId: ${fId}, status: ${status}, user: ${req.user.email}, role: ${req.user.role}, page: ${page}`);

  let baseQuery = "FROM files f LEFT JOIN users u ON f.user_id = u.id";
  let whereClauses = ["f.deleted_at IS NULL"];
  let params: any[] = [];

  try {
    if (req.user.role === "super_admin") {
      if (status === 'pending') {
        // Super admins can see pending files from admins to approve them if needed
        whereClauses.push("u.role = 'admin'");
      } else {
        // Normal view - Private by default even for super_admin
        whereClauses.push(`(
          f.user_id = ? 
          OR EXISTS (SELECT 1 FROM shares s WHERE s.item_type = 'file' AND s.item_id = f.id AND s.shared_with = ?)
        )`);
        params.push(req.user.id, req.user.id);
      }
      
      if (fId) {
        // Check if user has access to the folder
        const parentFolder: any = db.prepare("SELECT user_id FROM folders WHERE id = ?").get(fId);
        if (!parentFolder) return res.status(404).json({ error: "Folder not found" });

        const isShared = db.prepare("SELECT 1 FROM shares WHERE item_type = 'folder' AND item_id = ? AND shared_with = ?").get(fId, req.user.id);
        
        // Check if any ancestor is shared
        const isAncestorShared = db.prepare(`
          WITH RECURSIVE ancestors(id, parent_id) AS (
            SELECT id, parent_id FROM folders WHERE id = ?
            UNION ALL
            SELECT f.id, f.parent_id FROM folders f JOIN ancestors ON f.id = ancestors.parent_id
          )
          SELECT 1 FROM ancestors a JOIN shares s ON s.item_id = a.id WHERE s.item_type = 'folder' AND s.shared_with = ?
        `).get(fId, req.user.id);

        if (Number(parentFolder.user_id) !== Number(req.user.id) && !isShared && !isAncestorShared) {
          return res.status(403).json({ error: "Unauthorized access to this folder" });
        }

        whereClauses.push("f.folder_id = ?");
        params.push(fId);
      } else if (status) {
        whereClauses.push("f.status = ?");
        params.push(status);
      } else {
        whereClauses.push("f.folder_id IS NULL");
      }
    } else {
      // Private by default + Sharing (for employees and admins)
      whereClauses.push("u.role != 'super_admin'");
      
      if (fId) {
        // Check if user has access to the folder
        const parentFolder: any = db.prepare("SELECT user_id FROM folders WHERE id = ?").get(fId);
        if (!parentFolder) return res.status(404).json({ error: "Folder not found" });

        const isShared = db.prepare("SELECT 1 FROM shares WHERE item_type = 'folder' AND item_id = ? AND shared_with = ?").get(fId, req.user.id);
        
        // Check if any ancestor is shared
        const isAncestorShared = db.prepare(`
          WITH RECURSIVE ancestors(id, parent_id) AS (
            SELECT id, parent_id FROM folders WHERE id = ?
            UNION ALL
            SELECT f.id, f.parent_id FROM folders f JOIN ancestors ON f.id = ancestors.parent_id
          )
          SELECT 1 FROM ancestors a JOIN shares s ON s.item_id = a.id WHERE s.item_type = 'folder' AND s.shared_with = ?
        `).get(fId, req.user.id);

        if (Number(parentFolder.user_id) !== Number(req.user.id) && !isShared && !isAncestorShared) {
          return res.status(403).json({ error: "Unauthorized access to this folder" });
        }

        whereClauses.push("f.folder_id = ?");
        params.push(fId);
      } else {
        whereClauses.push("f.folder_id IS NULL");
        whereClauses.push(`(
          f.user_id = ? 
          OR EXISTS (SELECT 1 FROM shares s WHERE s.item_type = 'file' AND s.item_id = f.id AND s.shared_with = ?)
        )`);
        params.push(req.user.id, req.user.id);
      }
    }

    const whereSql = " WHERE " + whereClauses.join(" AND ");
    const files = db.prepare(`SELECT f.*, u.name as owner_name, COALESCE(f.department, u.department) as department ${baseQuery} ${whereSql} LIMIT ? OFFSET ?`).all(...params, limit, offset);
    const total = db.prepare(`SELECT COUNT(*) as count ${baseQuery} ${whereSql}`).get(...params) as any;

    res.json({ files, total: total.count, page, limit });
  } catch (error: any) {
    console.error("Failed to fetch files:", error.message);
    res.status(500).json({ error: error.message });
  }
});

app.put("/api/files/:id/status", authenticateToken, isAdmin, (req: any, res) => {
  const { id } = req.params;
  const { status } = req.body;
  if (!['approved', 'rejected', 'pending'].includes(status)) {
    return res.status(400).json({ error: "Invalid status" });
  }

  const file: any = db.prepare(`
    SELECT f.*, u.role as owner_role 
    FROM files f 
    JOIN users u ON f.user_id = u.id 
    WHERE f.id = ?
  `).get(id);

  if (!file) return res.status(404).json({ error: "File not found" });

  const requesterRole = req.user.role;
  const ownerRole = file.owner_role;

  if (requesterRole === "admin") {
    // System Admins (admin role) can approve files from employees and admins
    if (ownerRole === "super_admin") {
      return res.status(403).json({ error: "Admins cannot approve files uploaded by Super Admins" });
    }
  } else if (requesterRole === "super_admin") {
    // Super admin can approve anything
  }

  db.prepare("UPDATE files SET status = ? WHERE id = ?").run(status, id);
  res.json({ message: `File status updated to ${status}` });
});

app.post("/api/files/upload", authenticateToken, upload.single("file"), (req: any, res) => {
  const { folderId, description } = req.body;
  const userId = req.user.id;
  const department = req.user.department || null;

  console.log("Upload request received:", {
    file: req.file ? req.file.originalname : "No file",
    folderId: folderId,
    userId: userId,
    department: department,
    description: description
  });

  if (!req.file) {
    console.error("No file uploaded in request");
    return res.status(400).json({ error: "No file uploaded" });
  }
  
  const fId = (folderId && folderId !== "" && folderId !== "null" && folderId !== "undefined") ? parseInt(folderId, 10) : null;
  
  try {
    const fileBuffer = fs.readFileSync(req.file.path);
    const hash = crypto.createHash('md5').update(fileBuffer).digest('hex');

    // Check for duplication by hash and user
    const existingByHash = db.prepare("SELECT id FROM files WHERE hash = ? AND user_id = ? AND deleted_at IS NULL")
      .get(hash, userId);
    
    if (existingByHash) {
      if (fs.existsSync(req.file.path)) {
        fs.unlinkSync(req.file.path);
      }
      return res.status(400).json({ error: "You have already uploaded this file content" });
    }

    // Check for duplication by name in the same folder
    const existingByName = db.prepare("SELECT id FROM files WHERE original_name = ? AND folder_id IS ? AND user_id = ? AND deleted_at IS NULL")
      .get(req.file.originalname, fId, userId);
    
    if (existingByName) {
      if (fs.existsSync(req.file.path)) {
        fs.unlinkSync(req.file.path);
      }
      return res.status(400).json({ error: "A file with this name already exists in this folder" });
    }

    const initialStatus = "approved";

    const result = db.prepare(
      "INSERT INTO files (name, original_name, mime_type, size, hash, path, folder_id, user_id, department, description, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    ).run(
      req.file.filename,
      req.file.originalname,
      req.file.mimetype,
      req.file.size,
      hash,
      req.file.path,
      fId,
      userId,
      department,
      description || null,
      initialStatus
    );
    console.log("File inserted into DB successfully:", result);
    res.status(201).json({ message: "File uploaded successfully" });
  } catch (error: any) {
    console.error("DB Insert failed for file upload:", error.message);
    res.status(400).json({ error: "Database error: " + error.message });
  }
});

app.get("/api/files/download/:id", authenticateToken, (req: any, res) => {
  const { id } = req.params;
  const file: any = db.prepare("SELECT f.*, u.role as owner_role FROM files f JOIN users u ON f.user_id = u.id WHERE f.id = ?").get(id);
  if (!file) return res.status(404).json({ error: "File not found" });

  const isSuper = req.user.role === "super_admin";
  const isAdminRole = req.user.role === "admin";
  const isOwner = Number(file.user_id) === Number(req.user.id);

  // Check if explicitly shared
  const isShared = db.prepare("SELECT 1 FROM shares WHERE item_type = 'file' AND item_id = ? AND shared_with = ?").get(id, req.user.id);
  
  // Check if folder or any ancestor folder is shared
  let isFolderShared = false;
  if (file.folder_id) {
    isFolderShared = !!db.prepare(`
      WITH RECURSIVE ancestors(id, parent_id) AS (
        SELECT id, parent_id FROM folders WHERE id = ?
        UNION ALL
        SELECT f.id, f.parent_id FROM folders f JOIN ancestors ON f.id = ancestors.parent_id
      )
      SELECT 1 FROM ancestors a JOIN shares s ON s.item_id = a.id WHERE s.item_type = 'folder' AND s.shared_with = ?
    `).get(file.folder_id, req.user.id);
  }

  if (!isSuper && !isOwner && !isShared && !isFolderShared) {
    if (isAdminRole) {
      if (file.owner_role === "super_admin") return res.status(403).json({ error: "Unauthorized" });
    } else {
      return res.status(403).json({ error: "Unauthorized" });
    }
  }

  if (!fs.existsSync(file.path)) {
    return res.status(404).json({ error: "Physical file not found" });
  }

  res.download(file.path, file.original_name);
});

app.delete("/api/files/:id", authenticateToken, (req: any, res) => {
  const { id } = req.params;
  const fileIdNum = Number(id);
  
  if (isNaN(fileIdNum)) {
    return res.status(400).json({ error: "Invalid file ID" });
  }

  console.log(`[SERVER] DELETE /api/files/${fileIdNum} request from user ${req.user.id} (${req.user.role})`);
  try {
    const file: any = db.prepare("SELECT f.*, u.role as owner_role FROM files f JOIN users u ON f.user_id = u.id WHERE f.id = ?").get(fileIdNum);
    if (!file) {
      console.warn(`[SERVER] File ${fileIdNum} not found for deletion`);
      return res.status(404).json({ error: "File not found" });
    }

    console.log(`[SERVER] Found file:`, file);

    const isSuper = req.user.role === "super_admin";
    const isAdminRole = req.user.role === "admin";
    const isOwner = Number(file.user_id) === Number(req.user.id);

    if (!isSuper) {
      if (isAdminRole) {
        if (file.owner_role === "super_admin") return res.status(403).json({ error: "Unauthorized" });
      } else {
        if (!isOwner) {
          console.warn(`[SERVER] User ${req.user.id} unauthorized to delete file ${fileIdNum} (owned by ${file.user_id})`);
          return res.status(403).json({ error: "Unauthorized: You can only delete your own files" });
        }
      }
    }

    // Soft delete: set deleted_at and deleted_by
    console.log(`[SERVER] Attempting soft-delete for file ${fileIdNum} by user ${req.user.id}`);
    const result = db.prepare("UPDATE files SET deleted_at = CURRENT_TIMESTAMP, deleted_by = ? WHERE id = ?").run(req.user.id, fileIdNum);
    console.log(`[SERVER] File ${fileIdNum} soft-deleted. DB result:`, result);
    res.json({ message: "File moved to trash", result });
  } catch (error: any) {
    console.error(`[SERVER] Failed to delete file ${fileIdNum}:`, error.message, error.stack);
    res.status(500).json({ error: error.message });
  }
});

app.delete("/api/folders/:id", authenticateToken, (req: any, res) => {
  const { id } = req.params;
  console.log(`[SERVER] DELETE /api/folders/${id} request from user ${req.user.id} (${req.user.role})`);
  try {
    const folder: any = db.prepare("SELECT f.*, u.role as owner_role FROM folders f JOIN users u ON f.user_id = u.id WHERE f.id = ?").get(id);
    if (!folder) {
      console.warn(`[SERVER] Folder ${id} not found for deletion`);
      return res.status(404).json({ error: "Folder not found" });
    }

    console.log(`[SERVER] Found folder:`, folder);

    const isSuper = req.user.role === "super_admin";
    const isAdminRole = req.user.role === "admin";
    const isOwner = Number(folder.user_id) === Number(req.user.id);

    if (!isSuper) {
      if (isAdminRole) {
        if (folder.owner_role === "super_admin") return res.status(403).json({ error: "Unauthorized" });
      } else {
        if (!isOwner) {
          console.warn(`[SERVER] User ${req.user.id} unauthorized to delete folder ${id} (owned by ${folder.user_id})`);
          return res.status(403).json({ error: "Unauthorized: You can only delete your own folders" });
        }
      }
    }

    // Soft delete folder and its contents recursively
    const softDeleteFolder = (folderId: number, userId: number) => {
      if (isNaN(folderId)) {
        console.error(`[SERVER] Invalid folderId (NaN) passed to softDeleteFolder`);
        return;
      }
      console.log(`[SERVER] Recursively soft-deleting folder ${folderId} for user ${userId}`);
      db.prepare("UPDATE folders SET deleted_at = CURRENT_TIMESTAMP, deleted_by = ? WHERE id = ?").run(userId, folderId);
      db.prepare("UPDATE files SET deleted_at = CURRENT_TIMESTAMP, deleted_by = ? WHERE folder_id = ?").run(userId, folderId);
      
      const subfolders = db.prepare("SELECT id FROM folders WHERE parent_id = ?").all(folderId) as any[];
      subfolders.forEach(sub => softDeleteFolder(Number(sub.id), userId));
    };

    const folderIdNum = Number(id);
    if (isNaN(folderIdNum)) {
      return res.status(400).json({ error: "Invalid folder ID" });
    }

    softDeleteFolder(folderIdNum, req.user.id);
    console.log(`[SERVER] Folder ${id} and its contents soft-deleted`);
    res.json({ message: "Folder and its contents moved to trash" });
  } catch (error: any) {
    console.error(`[SERVER] Failed to delete folder ${id}:`, error.message, error.stack);
    res.status(500).json({ error: error.message });
  }
});

// --- TRASH MANAGEMENT ROUTES (ADMIN ONLY) ---
app.get("/api/admin/trash", authenticateToken, isAdmin, (req: any, res) => {
  const page = parseInt(req.query.page as string) || 1;
  const limit = parseInt(req.query.limit as string) || 10;
  const offset = (page - 1) * limit;

  const isSuper = req.user.role === "super_admin";

  const deletedFiles = db.prepare(`
    SELECT f.*, u.email as deleted_by_email 
    FROM files f 
    LEFT JOIN users u ON f.deleted_by = u.id 
    JOIN users owner ON f.user_id = owner.id
    WHERE f.deleted_at IS NOT NULL
    ${!isSuper ? "AND owner.role != 'super_admin'" : ""}
    LIMIT ? OFFSET ?
  `).all(limit, offset);
  
  const fileTotal = db.prepare(`
    SELECT COUNT(*) as count 
    FROM files f
    JOIN users owner ON f.user_id = owner.id
    WHERE f.deleted_at IS NOT NULL
    ${!isSuper ? "AND owner.role != 'super_admin'" : ""}
  `).get() as any;

  const deletedFolders = db.prepare(`
    SELECT f.*, u.email as deleted_by_email 
    FROM folders f 
    LEFT JOIN users u ON f.deleted_by = u.id 
    JOIN users owner ON f.user_id = owner.id
    WHERE f.deleted_at IS NOT NULL
    ${!isSuper ? "AND owner.role != 'super_admin'" : ""}
    LIMIT ? OFFSET ?
  `).all(limit, offset);

  const folderTotal = db.prepare(`
    SELECT COUNT(*) as count 
    FROM folders f
    JOIN users owner ON f.user_id = owner.id
    WHERE f.deleted_at IS NOT NULL
    ${!isSuper ? "AND owner.role != 'super_admin'" : ""}
  `).get() as any;

  res.json({ 
    files: deletedFiles, 
    folders: deletedFolders,
    fileTotal: fileTotal.count,
    folderTotal: folderTotal.count,
    page,
    limit
  });
});

app.post("/api/admin/trash/restore/:type/:id", authenticateToken, isAdmin, (req: any, res) => {
  const { type, id } = req.params;
  const isSuper = req.user.role === "super_admin";

  if (type === "file") {
    const file: any = db.prepare("SELECT f.*, u.role as owner_role FROM files f JOIN users u ON f.user_id = u.id WHERE f.id = ?").get(id);
    if (file && !isSuper && file.owner_role === "super_admin") return res.status(403).json({ error: "Unauthorized" });
    db.prepare("UPDATE files SET deleted_at = NULL, deleted_by = NULL WHERE id = ?").run(id);
  } else if (type === "folder") {
    const folder: any = db.prepare("SELECT f.*, u.role as owner_role FROM folders f JOIN users u ON f.user_id = u.id WHERE f.id = ?").get(id);
    if (folder && !isSuper && folder.owner_role === "super_admin") return res.status(403).json({ error: "Unauthorized" });
    
    const restoreFolderRecursively = (folderId: number) => {
      db.prepare("UPDATE folders SET deleted_at = NULL, deleted_by = NULL WHERE id = ?").run(folderId);
      db.prepare("UPDATE files SET deleted_at = NULL, deleted_by = NULL WHERE folder_id = ?").run(folderId);
      
      const subfolders = db.prepare("SELECT id FROM folders WHERE parent_id = ?").all(folderId) as any[];
      subfolders.forEach(sub => restoreFolderRecursively(sub.id));
    };
    restoreFolderRecursively(parseInt(id));
  }
  res.json({ message: "Item restored successfully" });
});

app.delete("/api/admin/trash/permanent/:type/:id", authenticateToken, isAdmin, (req: any, res) => {
  const { type, id } = req.params;
  const isSuper = req.user.role === "super_admin";
  
  if (type === "file") {
    const file: any = db.prepare("SELECT f.*, u.role as owner_role FROM files f JOIN users u ON f.user_id = u.id WHERE f.id = ?").get(id);
    if (file && !isSuper && file.owner_role === "super_admin") return res.status(403).json({ error: "Unauthorized" });

    if (file && fs.existsSync(file.path)) {
      try {
        fs.unlinkSync(file.path);
      } catch (err) {
        console.error(`Failed to delete file from disk: ${file.path}`, err);
      }
    }
    db.prepare("DELETE FROM files WHERE id = ?").run(id);
  } else if (type === "folder") {
    const folder: any = db.prepare("SELECT f.*, u.role as owner_role FROM folders f JOIN users u ON f.user_id = u.id WHERE f.id = ?").get(id);
    if (folder && !isSuper && folder.owner_role === "super_admin") return res.status(403).json({ error: "Unauthorized" });

    const permanentDeleteFolderRecursively = (folderId: number) => {
      // 1. Get all files in this folder and delete from disk
      const files = db.prepare("SELECT * FROM files WHERE folder_id = ?").all(folderId) as any[];
      files.forEach(file => {
        if (fs.existsSync(file.path)) {
          try {
            fs.unlinkSync(file.path);
          } catch (err) {
            console.error(`Failed to delete file from disk: ${file.path}`, err);
          }
        }
        db.prepare("DELETE FROM files WHERE id = ?").run(file.id);
      });

      // 2. Get all subfolders and recurse
      const subfolders = db.prepare("SELECT id FROM folders WHERE parent_id = ?").all(folderId) as any[];
      subfolders.forEach(sub => permanentDeleteFolderRecursively(sub.id));

      // 3. Delete the folder itself
      db.prepare("DELETE FROM folders WHERE id = ?").run(folderId);
    };
    
    permanentDeleteFolderRecursively(parseInt(id));
  }
  res.json({ message: "Item and its contents permanently deleted" });
});

app.put("/api/files/:id", authenticateToken, (req: any, res) => {
  const { id } = req.params;
  const { name } = req.body;
  const file: any = db.prepare("SELECT f.*, u.role as owner_role FROM files f JOIN users u ON f.user_id = u.id WHERE f.id = ?").get(id);
  if (!file) return res.status(404).json({ error: "File not found" });
  
  const isSuper = req.user.role === "super_admin";
  const isAdminRole = req.user.role === "admin";
  const isOwner = Number(file.user_id) === Number(req.user.id);

  if (!isSuper) {
    if (isAdminRole) {
      if (file.owner_role === "super_admin") return res.status(403).json({ error: "Unauthorized" });
    } else {
      if (!isOwner) return res.status(403).json({ error: "Unauthorized" });
    }
  }

  db.prepare("UPDATE files SET original_name = ? WHERE id = ?").run(name, id);
  res.json({ message: "File updated successfully" });
});

// --- SHARING ROUTES ---

// Search users to share with
app.get("/api/users/search", authenticateToken, (req, res) => {
  const { q } = req.query;
  if (!q) return res.json([]);
  const users = db.prepare("SELECT id, email, name FROM users WHERE email LIKE ? OR name LIKE ? LIMIT 10")
    .all(`%${q}%`, `%${q}%`);
  res.json(users);
});

// Internal sharing
app.post("/api/share/internal", authenticateToken, (req: any, res) => {
  const { itemType, itemId, sharedWithEmail, permission } = req.body;
  
  // Verify permission to share
  const table = itemType === "file" ? "files" : "folders";
  const item: any = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(itemId);
  if (!item) return res.status(404).json({ error: "Item not found" });
  
  const isOwner = item.user_id === req.user.id;
  const isAdmin = req.user.role === "admin" || req.user.role === "super_admin";
  
  if (!isOwner && !isAdmin) {
    return res.status(403).json({ error: "You don't have permission to share this item" });
  }

  const targetUser: any = db.prepare("SELECT id FROM users WHERE email = ?").get(sharedWithEmail);
  if (!targetUser) return res.status(404).json({ error: "User not found" });

  // Check if already shared
  const existing = db.prepare("SELECT id FROM shares WHERE item_type = ? AND item_id = ? AND shared_with = ?")
    .get(itemType, itemId, targetUser.id);
  
  if (existing) {
    db.prepare("UPDATE shares SET permission = ? WHERE id = ?").run(permission, existing.id);
  } else {
    db.prepare("INSERT INTO shares (item_type, item_id, shared_by, shared_with, permission) VALUES (?, ?, ?, ?, ?)")
      .run(itemType, itemId, req.user.id, targetUser.id, permission);
  }
  
  res.json({ message: "Item shared successfully" });
});

// Toggle public sharing
app.post("/api/share/public", authenticateToken, (req: any, res) => {
  const { itemType, itemId, enabled } = req.body;
  const table = itemType === "file" ? "files" : "folders";
  
  // Verify ownership
  const item: any = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(itemId);
  if (!item) return res.status(404).json({ error: "Item not found" });
  if (req.user.role !== "admin" && item.user_id !== req.user.id) {
    return res.status(403).json({ error: "Unauthorized" });
  }

  let token = null;
  if (enabled) {
    token = crypto.randomBytes(16).toString("hex");
  }

  db.prepare(`UPDATE ${table} SET public_token = ? WHERE id = ?`).run(token, itemId);
  res.json({ publicToken: token });
});

// Get shared with me
app.get("/api/shared-with-me", authenticateToken, (req: any, res) => {
  const { newOnly } = req.query;
  let query = `
    SELECT s.*, u.name as shared_by_name, u.email as shared_by_email,
           CASE 
             WHEN s.item_type = 'file' THEN f.original_name 
             WHEN s.item_type = 'folder' THEN fo.name 
           END as name,
           CASE 
             WHEN s.item_type = 'file' THEN f.mime_type 
             ELSE 'folder' 
           END as type,
           CASE 
             WHEN s.item_type = 'file' THEN f.size 
             ELSE NULL 
           END as size
    FROM shares s
    JOIN users u ON s.shared_by = u.id
    LEFT JOIN files f ON s.item_type = 'file' AND s.item_id = f.id
    LEFT JOIN folders fo ON s.item_type = 'folder' AND s.item_id = fo.id
    WHERE s.shared_with = ?
  `;

  if (newOnly === "true") {
    query += " AND s.notified = 0";
  }

  const shares = db.prepare(query).all(req.user.id);
  res.json(shares);
});

// Mark shares as notified
app.post("/api/shares/mark-notified", authenticateToken, (req: any, res) => {
  const { ids } = req.body;
  if (!Array.isArray(ids) || ids.length === 0) {
    return res.status(400).json({ error: "Invalid IDs" });
  }

  const placeholders = ids.map(() => "?").join(",");
  db.prepare(`UPDATE shares SET notified = 1 WHERE id IN (${placeholders}) AND shared_with = ?`)
    .run(...ids, req.user.id);
  
  res.json({ message: "Marked as notified" });
});

// Public access info
app.get("/api/public/:token", (req, res) => {
  const { token } = req.params;
  
  const file: any = db.prepare("SELECT * FROM files WHERE public_token = ?").get(token);
  if (file) {
    return res.json({ type: "file", item: { name: file.original_name, size: file.size, mime_type: file.mime_type, token: file.public_token } });
  }
  
  const folder: any = db.prepare("SELECT * FROM folders WHERE public_token = ?").get(token);
  if (folder) {
    return res.json({ type: "folder", item: { name: folder.name, token: folder.public_token } });
  }
  
  res.status(404).json({ error: "Link expired or invalid" });
});

// Download public file
app.get("/api/public/download/:token", (req, res) => {
  const { token } = req.params;
  const file: any = db.prepare("SELECT * FROM files WHERE public_token = ?").get(token);
  if (!file) return res.status(404).json({ error: "File not found" });
  
  if (fs.existsSync(file.path)) {
    res.download(file.path, file.original_name);
  } else {
    res.status(404).json({ error: "Physical file not found" });
  }
});

// --- STATS ROUTES ---
app.get("/api/stats", authenticateToken, (req: any, res) => {
  const isSuper = req.user.role === "super_admin";
  const userStats = db.prepare("SELECT role, COUNT(*) as count FROM users GROUP BY role").all();
  const fileCount = db.prepare(`
    SELECT COUNT(*) as count 
    FROM files f
    JOIN users u ON f.user_id = u.id
    WHERE f.deleted_at IS NULL
    ${!isSuper ? "AND u.role != 'super_admin'" : ""}
  `).get() as any;
  const folderCount = db.prepare(`
    SELECT COUNT(*) as count 
    FROM folders f
    JOIN users u ON f.user_id = u.id
    WHERE f.deleted_at IS NULL
    ${!isSuper ? "AND u.role != 'super_admin'" : ""}
  `).get() as any;
  const totalUsers = db.prepare("SELECT COUNT(*) as count FROM users").get() as any;
  const pendingFiles = db.prepare(`
    SELECT COUNT(*) as count 
    FROM files f
    JOIN users u ON f.user_id = u.id
    WHERE f.status = 'pending' AND f.deleted_at IS NULL
    ${req.user.role === 'admin' ? "AND u.role = 'employee'" : 
      req.user.role === 'super_admin' ? "AND u.role = 'admin'" : 
      "AND 1=0"}
  `).get() as any;

  res.json({
    users: userStats,
    files: fileCount,
    folders: folderCount,
    totalUsers: totalUsers,
    pendingFiles: pendingFiles
  });
});

// --- ADMIN MAINTENANCE ROUTES ---
app.get("/api/admin/metrics", authenticateToken, isAdmin, (req, res) => {
  const memoryUsage = process.memoryUsage();
  const uptime = process.uptime();
  
  res.json({
    memory: {
      rss: Math.round(memoryUsage.rss / 1024 / 1024) + " MB",
      heapTotal: Math.round(memoryUsage.heapTotal / 1024 / 1024) + " MB",
      heapUsed: Math.round(memoryUsage.heapUsed / 1024 / 1024) + " MB",
    },
    uptime: Math.round(uptime) + " seconds",
    nodeVersion: process.version,
    platform: process.platform,
    dbSize: fs.statSync("fms.sqlite").size
  });
});

app.get("/api/admin/backup", authenticateToken, isAdmin, (req: any, res) => {
  const backupFilename = `backup-${Date.now()}.sqlite`;
  const backupPath = path.join(UPLOADS_DIR, backupFilename);
  
  try {
    // In a real app, we'd use a proper backup tool, but for SQLite we can just copy the file
    // better-sqlite3 also has a backup method
    db.backup(backupPath)
      .then(() => {
        const stats = fs.statSync(backupPath);
        db.prepare("INSERT INTO backup_logs (filename, size, created_by) VALUES (?, ?, ?)").run(backupFilename, stats.size, req.user.id);
        res.download(backupPath, backupFilename);
      })
      .catch((err) => {
        res.status(500).json({ error: "Backup failed: " + err.message });
      });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.get("/api/admin/backups", authenticateToken, isAdmin, (req, res) => {
  const backups = db.prepare(`
    SELECT b.*, u.email as created_by_email 
    FROM backup_logs b 
    LEFT JOIN users u ON b.created_by = u.id 
    ORDER BY b.created_at DESC
  `).all();
  res.json(backups);
});

// Vite middleware for development
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
