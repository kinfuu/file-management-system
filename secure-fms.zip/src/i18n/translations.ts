export const translations = {
  en: {
    translation: {
      nav: {
        home: "Home",
        dashboard: "Dashboard",
        admin: "Admin Panel",
        about: "About",
        contact: "Contact",
        signIn: "Sign In",
        logout: "Logout"
      },
      home: {
        heroTitle: "Secure FMS",
        heroSubtitle: "",
        heroDescription: "Secure FMS provides a robust, secure, and intuitive platform for managing your organization's files. With role-based access control and seamless collaboration, your data is always safe and accessible.",
        goToDashboard: "Go to Dashboard",
        features: "Features",
        featuresTitle: "Everything you need to manage files",
        orgTitle: "Smart Organization",
        orgDesc: "Automatically categorize and tag your documents for effortless retrieval and management.",
        roleTitle: "Role-Based Access",
        roleDesc: "Granular permissions ensure that only authorized personnel can access sensitive data.",
        fastTitle: "Lightning Fast",
        fastDesc: "Optimized for performance, allowing you to upload and retrieve files in seconds."
      },
      login: {
        welcome: "Welcome back",
        subtitle: "Please enter your details to access your files",
        email: "Email Address",
        password: "Password",
        signIn: "Sign in",
        forgotPassword: "Forgot Password?"
      }
    }
  },
  am: {
    translation: {
      nav: {
        home: "ቤት",
        dashboard: "ዳሽቦርድ",
        admin: "የአስተዳዳሪ ፓነል",
        about: "ስለ እኛ",
        contact: "እኛን ያግኙ",
        signIn: "ግባ",
        logout: "ውጣ"
      },
      home: {
        heroTitle: "Secure FMS",
        heroSubtitle: "",
        heroDescription: "Secure FMS የድርጅትዎን ፋይሎች ለማስተዳደር ጠንካራ፣ ደህንነቱ የተጠበቀ እና ሊታወቅ የሚችል መድረክ ይሰጣል። በ ሚና ላይ የተመሰረተ የመዳረሻ ቁጥጥር እና እንከን የለሽ ትብብር፣ የእርስዎ ውሂብ ሁል ጊዜ ደህንነቱ የተጠበቀ እና ተደራሽ ነው።",
        goToDashboard: "ወደ ዳሽቦርድ ይሂዱ",
        features: "ባህሪያት",
        featuresTitle: "ፋይሎችን ለማስተዳደር የሚያስፈልግዎ ነገር ሁሉ",
        orgTitle: "ብልህ ድርጅት",
        orgDesc: "ሰነዶችዎን ያለምንም ጥረት ለማምጣት እና ለማስተዳደር በራስ-ሰር ይመድቡ እና መለያ ይስጡ።",
        roleTitle: "በሚና ላይ የተመሰረተ መዳረሻ",
        roleDesc: "ጥቃቅን ፈቃዶች የተፈቀደላቸው ሰራተኞች ብቻ ሚስጥራዊ መረጃን ማግኘት እንደሚችሉ ያረጋግጣሉ።",
        fastTitle: "በጣም ፈጣን",
        fastDesc: "ለአፈጻጸም የተመቻቸ፣ ፋይሎችን በሰከንዶች ውስጥ እንዲሰቅሉ እና እንዲያወጡ ያስችልዎታል።"
      },
      login: {
        welcome: "እንኳን ደህና መጡ",
        subtitle: "እባክዎ ፋይሎችዎን ለማግኘት ዝርዝሮችዎን ያስገቡ",
        email: "የኢሜል አድራሻ",
        password: "የይለፍ ቃል",
        signIn: "ግባ",
        forgotPassword: "የይለፍ ቃል ረስተዋል?"
      }
    }
  },
  om: {
    translation: {
      nav: {
        home: "Mana",
        dashboard: "Daashboordii",
        admin: "Paaneelii Bulchiinsaa",
        about: "Waa'ee Keenya",
        contact: "Nu Quunnamaa",
        signIn: "Seeni",
        logout: "Ba'i"
      },
      home: {
        heroTitle: "Secure FMS",
        heroSubtitle: "",
        heroDescription: "Secure FMS faayila dhaabbata keessanii bulchuuf sirna cimaa, amansiisaa fi salphaa ta'e dhiyeessa. To'annoo seenuun gahee irratti hundaa'e fi waliin hojjechuun walitti hidhameen, ragaan keessan yeroo hunda nagaa fi kan argamudha.",
        goToDashboard: "Gara Daashboordiitti Deemi",
        features: "Amaloota",
        featuresTitle: "Waan faayila bulchuuf isin barbaachisu hunda",
        orgTitle: "Gurmaa'ina Bilchaataa",
        orgDesc: "Salphaatti argachuu fi bulchuuf galmeewwan keessan ofumaan ramaduu fi mallattoo itti gochuu.",
        roleTitle: "Seensa Gahee Irratti Hundaa'e",
        roleDesc: "Hayyamni bal'aan hojjettoonni hayyamameef qofti ragaa iccitii akka argatan mirkaneessa.",
        fastTitle: "Baay'ee Ariifataa",
        fastDesc: "Hojii raawwachiisuuf kan fooyya'e, faayila seekondii muraasa keessatti fe'uu fi argachuuf isin dandeessisa."
      },
      login: {
        welcome: "Baga Nagaan Dhuftan",
        subtitle: "Maaloo faayila keessan argachuuf odeeffannoo keessan galchaa",
        email: "Teessoo Imeeyilii",
        password: "Jecha Iccitii",
        signIn: "Seeni",
        forgotPassword: "Jecha iccitii dagattanii?"
      }
    }
  }
};
