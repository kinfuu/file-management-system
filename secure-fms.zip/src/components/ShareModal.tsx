import React, { useState, useEffect } from "react";
import { X, Share2, Link, Users, Copy, Check, Send, Globe, MessageCircle, SendHorizontal, Facebook, Mail } from "lucide-react";
import api from "../api/axios";
import { useToast } from "../context/ToastContext";

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  item: {
    id: number;
    name: string;
    type: "file" | "folder";
    public_token?: string | null;
  };
}

const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose, item }) => {
  const { showToast } = useToast();
  const [activeTab, setActiveTab] = useState<"internal" | "public">("internal");
  const [searchQuery, setSearchQuery] = useState("");
  const [users, setUsers] = useState<any[]>([]);
  const [selectedUser, setSelectedUser] = useState<any | null>(null);
  const [permission, setPermission] = useState("view");
  const [isPublic, setIsPublic] = useState(!!item.public_token);
  const [publicToken, setPublicToken] = useState(item.public_token || "");
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (searchQuery.length > 1) {
      const delayDebounceFn = setTimeout(() => {
        fetchUsers();
      }, 300);
      return () => clearTimeout(delayDebounceFn);
    } else {
      setUsers([]);
    }
  }, [searchQuery]);

  const fetchUsers = async () => {
    try {
      const response = await api.get(`/users/search?q=${searchQuery}`);
      setUsers(response.data);
    } catch (error) {
      console.error("Failed to fetch users", error);
    }
  };

  const handleInternalShare = async () => {
    if (!selectedUser) return;
    setLoading(true);
    try {
      await api.post("/share/internal", {
        itemType: item.type,
        itemId: item.id,
        sharedWithEmail: selectedUser.email,
        permission
      });
      showToast(`Shared with ${selectedUser.name} successfully`, "success");
      setSelectedUser(null);
      setSearchQuery("");
    } catch (error) {
      console.error("Failed to share", error);
      showToast("Failed to share item", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleTogglePublic = async () => {
    setLoading(true);
    try {
      const response = await api.post("/share/public", {
        itemType: item.type,
        itemId: item.id,
        enabled: !isPublic
      });
      setIsPublic(!isPublic);
      setPublicToken(response.data.publicToken || "");
      showToast(isPublic ? "Public access disabled" : "Public access enabled", "success");
    } catch (error) {
      console.error("Failed to toggle public share", error);
      showToast("Failed to toggle public access", "error");
    } finally {
      setLoading(false);
    }
  };

  const publicUrl = `${window.location.origin}/public/${publicToken}`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(publicUrl);
    setCopied(true);
    showToast("Link copied to clipboard", "success");
    setTimeout(() => setCopied(false), 2000);
  };

  const shareVia = (platform: string) => {
    const text = `Check out this ${item.type}: ${item.name}`;
    let url = "";
    switch (platform) {
      case "whatsapp":
        url = `https://wa.me/?text=${encodeURIComponent(text + " " + publicUrl)}`;
        break;
      case "telegram":
        url = `https://t.me/share/url?url=${encodeURIComponent(publicUrl)}&text=${encodeURIComponent(text)}`;
        break;
      case "facebook":
        url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(publicUrl)}`;
        break;
      case "email":
        url = `mailto:?subject=${encodeURIComponent(text)}&body=${encodeURIComponent(text + "\n\n" + publicUrl)}`;
        break;
    }
    window.open(url, "_blank");
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-100 rounded-lg">
              <Share2 className="h-5 w-5 text-indigo-600" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Share {item.type}</h2>
              <p className="text-xs text-slate-500 truncate max-w-[200px]">{item.name}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full transition-colors">
            <X className="h-5 w-5 text-slate-500" />
          </button>
        </div>

        <div className="flex border-b border-slate-100">
          <button
            onClick={() => setActiveTab("internal")}
            className={`flex-1 py-3 text-sm font-medium transition-colors flex items-center justify-center gap-2 ${
              activeTab === "internal" ? "text-indigo-600 border-b-2 border-indigo-600" : "text-slate-500 hover:text-slate-700"
            }`}
          >
            <Users className="h-4 w-4" />
            Internal
          </button>
          <button
            onClick={() => setActiveTab("public")}
            className={`flex-1 py-3 text-sm font-medium transition-colors flex items-center justify-center gap-2 ${
              activeTab === "public" ? "text-indigo-600 border-b-2 border-indigo-600" : "text-slate-500 hover:text-slate-700"
            }`}
          >
            <Globe className="h-4 w-4" />
            Public Link
          </button>
        </div>

        <div className="p-6">
          {activeTab === "internal" ? (
            <div className="space-y-4">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search user by name or email..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-4 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                />
                {users.length > 0 && !selectedUser && (
                  <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-slate-200 rounded-xl shadow-lg z-10 max-h-40 overflow-y-auto">
                    {users.map((u) => (
                      <button
                        key={u.id}
                        onClick={() => setSelectedUser(u)}
                        className="w-full px-4 py-2 text-left hover:bg-slate-50 text-sm flex flex-col border-b border-slate-50 last:border-0"
                      >
                        <span className="font-medium text-slate-900">{u.name}</span>
                        <span className="text-xs text-slate-500">{u.email}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {selectedUser && (
                <div className="p-3 bg-indigo-50 rounded-xl border border-indigo-100 flex items-center justify-between">
                  <div className="flex flex-col">
                    <span className="text-sm font-medium text-indigo-900">{selectedUser.name}</span>
                    <span className="text-xs text-indigo-600">{selectedUser.email}</span>
                  </div>
                  <button onClick={() => setSelectedUser(null)} className="text-indigo-400 hover:text-indigo-600">
                    <X className="h-4 w-4" />
                  </button>
                </div>
              )}

              <div className="flex items-center gap-4">
                <select
                  value={permission}
                  onChange={(e) => setPermission(e.target.value)}
                  className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="view">Can view</option>
                  <option value="edit">Can edit</option>
                </select>
                <button
                  onClick={handleInternalShare}
                  disabled={!selectedUser || loading}
                  className="px-6 py-2 bg-indigo-600 text-white rounded-xl text-sm font-medium hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center gap-2"
                >
                  <Send className="h-4 w-4" />
                  Share
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-200">
                <div className="flex items-center gap-3">
                  <Globe className={`h-5 w-5 ${isPublic ? "text-emerald-500" : "text-slate-400"}`} />
                  <div>
                    <p className="text-sm font-medium text-slate-900">Public Access</p>
                    <p className="text-xs text-slate-500">Anyone with the link can view</p>
                  </div>
                </div>
                <button
                  onClick={handleTogglePublic}
                  disabled={loading}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${
                    isPublic ? "bg-indigo-600" : "bg-slate-300"
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      isPublic ? "translate-x-6" : "translate-x-1"
                    }`}
                  />
                </button>
              </div>

              {isPublic && (
                <div className="space-y-4 animate-in slide-in-from-top-2 duration-300">
                  <div className="flex gap-2">
                    <div className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-600 truncate flex items-center">
                      {publicUrl}
                    </div>
                    <button
                      onClick={copyToClipboard}
                      className="p-2 bg-indigo-50 text-indigo-600 rounded-xl hover:bg-indigo-100 transition-colors"
                    >
                      {copied ? <Check className="h-5 w-5" /> : <Copy className="h-5 w-5" />}
                    </button>
                  </div>

                  <div className="pt-2">
                    <p className="text-xs font-medium text-slate-500 mb-3 uppercase tracking-wider">Share via</p>
                    <div className="flex justify-between gap-2">
                      <button
                        onClick={() => shareVia("whatsapp")}
                        className="flex-1 flex flex-col items-center gap-2 p-3 rounded-xl hover:bg-emerald-50 transition-colors group"
                      >
                        <div className="p-2 bg-emerald-100 rounded-lg group-hover:scale-110 transition-transform">
                          <MessageCircle className="h-5 w-5 text-emerald-600" />
                        </div>
                        <span className="text-[10px] font-medium text-slate-600">WhatsApp</span>
                      </button>
                      <button
                        onClick={() => shareVia("telegram")}
                        className="flex-1 flex flex-col items-center gap-2 p-3 rounded-xl hover:bg-sky-50 transition-colors group"
                      >
                        <div className="p-2 bg-sky-100 rounded-lg group-hover:scale-110 transition-transform">
                          <SendHorizontal className="h-5 w-5 text-sky-600" />
                        </div>
                        <span className="text-[10px] font-medium text-slate-600">Telegram</span>
                      </button>
                      <button
                        onClick={() => shareVia("facebook")}
                        className="flex-1 flex flex-col items-center gap-2 p-3 rounded-xl hover:bg-blue-50 transition-colors group"
                      >
                        <div className="p-2 bg-blue-100 rounded-lg group-hover:scale-110 transition-transform">
                          <Facebook className="h-5 w-5 text-blue-600" />
                        </div>
                        <span className="text-[10px] font-medium text-slate-600">Facebook</span>
                      </button>
                      <button
                        onClick={() => shareVia("email")}
                        className="flex-1 flex flex-col items-center gap-2 p-3 rounded-xl hover:bg-red-50 transition-colors group"
                      >
                        <div className="p-2 bg-red-100 rounded-lg group-hover:scale-110 transition-transform">
                          <Mail className="h-5 w-5 text-red-600" />
                        </div>
                        <span className="text-[10px] font-medium text-slate-600">Email</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ShareModal;
