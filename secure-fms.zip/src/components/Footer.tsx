import React from "react";

const Footer: React.FC = () => {
  return (
    <footer className="bg-emerald-600 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col items-center justify-center text-center">
        <p className="text-base text-emerald-50">&copy; 2026 Secure FMS. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;
