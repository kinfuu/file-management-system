import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { AlertTriangle, X, Loader2 } from "lucide-react";

interface ConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => Promise<void> | void;
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  variant?: "danger" | "primary";
}

const ConfirmModal: React.FC<ConfirmModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  title,
  message,
  confirmText = "Confirm",
  cancelText = "Cancel",
  variant = "danger",
}) => {
  const [isSubmitting, setIsSubmitting] = React.useState(false);

  React.useEffect(() => {
    if (isOpen) {
      setIsSubmitting(false);
    }
  }, [isOpen]);
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 overflow-hidden"
          >
            <div className="flex items-start space-x-4">
              <div className={`p-3 rounded-xl ${variant === "danger" ? "bg-red-50" : "bg-indigo-50"}`}>
                <AlertTriangle className={`h-6 w-6 ${variant === "danger" ? "text-red-600" : "text-indigo-600"}`} />
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-slate-900">{title}</h3>
                <p className="mt-2 text-slate-500 text-sm leading-relaxed">{message}</p>
              </div>
              <button
                onClick={onClose}
                className="p-2 text-slate-400 hover:text-slate-600 rounded-full transition-colors"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="flex space-x-3 mt-8">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 px-4 py-3 border border-slate-200 text-slate-700 font-semibold rounded-xl hover:bg-slate-50 transition-all"
              >
                {cancelText}
              </button>
              <button
                type="button"
                disabled={isSubmitting}
                onClick={async () => {
                  console.log("ConfirmModal: Confirm clicked");
                  setIsSubmitting(true);
                  try {
                    await onConfirm();
                    console.log("ConfirmModal: onConfirm finished");
                    onClose();
                  } catch (error) {
                    console.error("ConfirmModal: onConfirm failed", error);
                    setIsSubmitting(false);
                  }
                }}
                className={`flex-1 px-4 py-3 text-white font-semibold rounded-xl transition-all shadow-lg flex items-center justify-center space-x-2 ${
                  isSubmitting ? "opacity-70 cursor-not-allowed" : ""
                } ${
                  variant === "danger"
                    ? "bg-red-600 hover:bg-red-700 shadow-red-100"
                    : "bg-indigo-600 hover:bg-indigo-700 shadow-indigo-100"
                }`}
              >
                {isSubmitting && <Loader2 className="h-4 w-4 animate-spin" />}
                <span>{isSubmitting ? "Processing..." : confirmText}</span>
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default ConfirmModal;
