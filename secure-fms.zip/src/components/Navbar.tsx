import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { LogOut, User, FolderOpen, Shield, FileText, Globe } from "lucide-react";
import { useTranslation } from "react-i18next";
import { motion, AnimatePresence } from "motion/react";
import api from "../api/axios";
import { cn } from "../lib/utils";

const Navbar: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { t, i18n } = useTranslation();
  const [isLangOpen, setIsLangOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const changeLanguage = (lng: string) => {
    i18n.changeLanguage(lng);
  };

  return (
    <nav className="bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center space-x-8">
            <Link to="/" className="flex items-center space-x-2">
              <div className="bg-indigo-600 p-1.5 rounded-lg">
                <FolderOpen className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold text-slate-900 tracking-tight">Secure FMS</span>
            </Link>
            
            <div className="hidden md:flex space-x-4">
              <Link
                to="/"
                className="text-slate-600 hover:text-indigo-600 px-3 py-2 rounded-md text-sm font-medium transition-colors"
              >
                {t('nav.home')}
              </Link>
              {user && (
                <Link
                  to="/dashboard"
                  className="text-slate-600 hover:text-indigo-600 px-3 py-2 rounded-md text-sm font-medium transition-colors flex items-center space-x-1"
                >
                  <FileText className="h-4 w-4" />
                  <span>{t('nav.dashboard')}</span>
                </Link>
              )}
              {(user?.role === "admin" || user?.role === "super_admin") && (
                <Link
                  to="/admin"
                  className="text-slate-600 hover:text-indigo-600 px-3 py-2 rounded-md text-sm font-medium transition-colors flex items-center space-x-1"
                >
                  <Shield className="h-4 w-4" />
                  <span>{t('nav.admin')}</span>
                </Link>
              )}
              <Link
                to="/about"
                className="text-slate-600 hover:text-indigo-600 px-3 py-2 rounded-md text-sm font-medium transition-colors"
              >
                {t('nav.about')}
              </Link>
              <Link
                to="/contact"
                className="text-slate-600 hover:text-indigo-600 px-3 py-2 rounded-md text-sm font-medium transition-colors"
              >
                {t('nav.contact')}
              </Link>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <div className="relative">
              <button
                onClick={() => setIsLangOpen(!isLangOpen)}
                className="flex items-center space-x-2 bg-slate-100 px-3 py-1.5 rounded-lg text-[10px] font-bold text-slate-700 hover:bg-slate-200 transition-all border border-slate-200"
              >
                <Globe className="h-3.5 w-3.5 text-indigo-600" />
                <span>{i18n.language === 'en' ? 'EN' : i18n.language === 'am' ? 'አማ' : 'ORM'}</span>
              </button>

              {isLangOpen && (
                <>
                  <div 
                    className="fixed inset-0 z-40" 
                    onClick={() => setIsLangOpen(false)}
                  />
                  <div className="absolute right-0 mt-2 w-28 bg-white border border-slate-200 rounded-xl shadow-xl py-1 z-50 overflow-hidden animate-in fade-in zoom-in duration-200">
                    {[
                      { code: 'en', label: 'English' },
                      { code: 'am', label: 'አማርኛ' },
                      { code: 'om', label: 'Oromiffa' }
                    ].map((lng) => (
                      <button
                        key={lng.code}
                        onClick={() => {
                          changeLanguage(lng.code);
                          setIsLangOpen(false);
                        }}
                        className={`w-full text-left px-4 py-2 text-[10px] font-bold transition-colors ${
                          i18n.language === lng.code 
                            ? 'bg-indigo-50 text-indigo-600' 
                            : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                        }`}
                      >
                        {lng.label}
                      </button>
                    ))}
                  </div>
                </>
              )}
            </div>

            {user ? (
              <>
                <div className="flex items-center space-x-2 px-3 py-1.5 bg-slate-50 rounded-full border border-slate-200">
                  <div className="bg-slate-200 p-1 rounded-full">
                    <User className="h-4 w-4 text-slate-600" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-xs font-semibold text-slate-900 leading-none">{user.name}</span>
                    <span className="text-[10px] text-slate-500 uppercase tracking-wider font-bold">{user.role}</span>
                  </div>
                </div>
                
                <button
                  onClick={handleLogout}
                  className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-full transition-all"
                  title={t('nav.logout')}
                >
                  <LogOut className="h-5 w-5" />
                </button>
              </>
            ) : (
              <Link
                to="/login"
                className="flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-xl text-white bg-indigo-600 hover:bg-indigo-700 transition-all shadow-md shadow-indigo-100"
              >
                {t('nav.signIn')}
              </Link>
            )}
          </div>
        </div>
      </div>

      <AnimatePresence>
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
