import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { File, Folder, Download, AlertCircle, Loader2, Globe, Shield } from "lucide-react";
import api from "../api/axios";

const PublicAccess: React.FC = () => {
  const { token } = useParams<{ token: string }>();
  const [item, setItem] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchItem();
  }, [token]);

  const fetchItem = async () => {
    try {
      const response = await api.get(`/public/${token}`);
      setItem(response.data);
    } catch (err: any) {
      setError(err.response?.data?.error || "Failed to load shared item");
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = () => {
    window.open(`${api.defaults.baseURL}/public/download/${token}`, "_blank");
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
        <Loader2 className="h-10 w-10 text-indigo-600 animate-spin mb-4" />
        <p className="text-slate-600 animate-pulse">Loading shared content...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
        <div className="bg-white p-8 rounded-3xl shadow-xl max-w-md w-full text-center">
          <div className="bg-red-50 p-4 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6">
            <AlertCircle className="h-10 w-10 text-red-500" />
          </div>
          <h1 className="text-2xl font-bold text-slate-900 mb-2">Access Denied</h1>
          <p className="text-slate-500 mb-8">{error}</p>
          <a href="/" className="inline-block px-8 py-3 bg-indigo-600 text-white rounded-2xl font-semibold hover:bg-indigo-700 transition-all">
            Go to Homepage
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
      <div className="bg-white p-8 rounded-3xl shadow-2xl max-w-md w-full border border-slate-100 relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-2 bg-indigo-600" />
        
        <div className="flex items-center justify-center mb-8">
          <div className="bg-indigo-50 p-4 rounded-2xl">
            {item.type === "file" ? (
              <File className="h-12 w-12 text-indigo-600" />
            ) : (
              <Folder className="h-12 w-12 text-indigo-600" />
            )}
          </div>
        </div>

        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold text-slate-900 mb-2 truncate" title={item.item.name}>
            {item.item.name}
          </h1>
          <div className="flex items-center justify-center gap-2 text-slate-500 text-sm">
            <Globe className="h-4 w-4" />
            <span>Publicly Shared</span>
            {item.item.size && (
              <>
                <span className="mx-1">•</span>
                <span>{(item.item.size / 1024 / 1024).toFixed(2)} MB</span>
              </>
            )}
          </div>
        </div>

        <div className="space-y-4">
          {item.type === "file" ? (
            <button
              onClick={handleDownload}
              className="w-full flex items-center justify-center gap-3 px-8 py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 hover:scale-[1.02] active:scale-[0.98] transition-all shadow-lg shadow-indigo-200"
            >
              <Download className="h-5 w-5" />
              Download File
            </button>
          ) : (
            <div className="p-4 bg-amber-50 border border-amber-100 rounded-2xl text-amber-800 text-sm text-center">
              <p className="font-medium mb-1">Folder Access</p>
              <p className="opacity-80">This folder is shared. Please login to view its full contents if you have internal access.</p>
            </div>
          )}
          
          <div className="flex items-center justify-center gap-2 pt-4 border-t border-slate-100 mt-4">
            <Shield className="h-4 w-4 text-slate-400" />
            <span className="text-xs text-slate-400">Securely shared via FMS</span>
          </div>
        </div>
      </div>
      
      <p className="mt-8 text-slate-400 text-sm">
        Powered by <span className="font-bold text-slate-500">File Management System</span>
      </p>
    </div>
  );
};

export default PublicAccess;
