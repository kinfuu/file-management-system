import React, { useState, useEffect } from "react";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";
import { UserPlus, Trash2, Edit2, User, Mail, Shield, ShieldAlert, X, Check, Search, Loader2, FileCheck, Activity, Database as DbIcon, Download, Clock, RotateCcw, Building2, Lock } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "../utils/cn";
import ConfirmModal from "../components/ConfirmModal";
import Pagination from "../components/Pagination";

interface UserData {
  id: number;
  email: string;
  name: string;
  father_name?: string;
  grandfather_name?: string;
  role: "super_admin" | "admin" | "employee";
  department?: string;
  phone?: string;
  created_at: string;
}

interface Department {
  id: number;
  name: string;
  description?: string;
  created_at: string;
}

interface PendingFile {
  id: number;
  original_name: string;
  owner_name: string;
  owner_role: string;
  department: string;
  description?: string;
  size: number;
  created_at: string;
}

interface SystemMetrics {
  memory: {
    rss: string;
    heapTotal: string;
    heapUsed: string;
  };
  uptime: string;
  nodeVersion: string;
  platform: string;
  dbSize: number;
}

interface BackupLog {
  id: number;
  filename: string;
  size: number;
  created_at: string;
}

interface TrashItem {
  id: number;
  name?: string;
  original_name?: string;
  deleted_at: string;
  deleted_by_email: string;
  type: "file" | "folder";
}

const AdminDashboard: React.FC = () => {
  const { user: currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState<"users" | "approvals" | "maintenance" | "trash" | "departments" | "passwords">("users");
  const [users, setUsers] = useState<UserData[]>([]);
  const [pendingFiles, setPendingFiles] = useState<PendingFile[]>([]);
  const [metrics, setMetrics] = useState<SystemMetrics | null>(null);
  const [backups, setBackups] = useState<BackupLog[]>([]);
  const [trashItems, setTrashItems] = useState<TrashItem[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isResetModalOpen, setIsResetModalOpen] = useState(false);
  const [isDeptModalOpen, setIsDeptModalOpen] = useState(false);
  const [resettingUser, setResettingUser] = useState<UserData | null>(null);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [editingUser, setEditingUser] = useState<UserData | null>(null);
  const [editingDept, setEditingDept] = useState<Department | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [error, setError] = useState("");
  
  // Pagination state
  const [userPage, setUserPage] = useState(1);
  const [userTotal, setUserTotal] = useState(0);
  const [pendingPage, setPendingPage] = useState(1);
  const [pendingTotal, setPendingTotal] = useState(0);
  const [trashPage, setTrashPage] = useState(1);
  const [trashTotal, setTrashTotal] = useState(0);
  const ITEMS_PER_PAGE = 10;

  const [confirmConfig, setConfirmConfig] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: "",
    message: "",
    onConfirm: () => {},
  });

  // Form state
  const [formData, setFormData] = useState({
    email: "",
    name: "",
    father_name: "",
    grandfather_name: "",
    role: "employee" as "super_admin" | "admin" | "employee",
    department: "",
    phone: "",
    password: "",
  });

  const [deptFormData, setDeptFormData] = useState({
    name: "",
    description: "",
  });

  const fetchUsers = async () => {
    try {
      const response = await api.get(`/users?page=${userPage}&limit=${ITEMS_PER_PAGE}`);
      setUsers(response.data.users);
      setUserTotal(response.data.total);
    } catch (error) {
      console.error("Failed to fetch users", error);
    }
  };

  const fetchPendingFiles = async () => {
    try {
      const response = await api.get(`/files?status=pending&page=${pendingPage}&limit=${ITEMS_PER_PAGE}`);
      setPendingFiles(response.data.files);
      setPendingTotal(response.data.total);
    } catch (error) {
      console.error("Failed to fetch pending files", error);
    }
  };

  const fetchMetrics = async () => {
    try {
      const response = await api.get("/admin/metrics");
      setMetrics(response.data);
    } catch (error) {
      console.error("Failed to fetch metrics", error);
    }
  };

  const fetchBackups = async () => {
    try {
      const response = await api.get("/admin/backups");
      setBackups(response.data);
    } catch (error) {
      console.error("Failed to fetch backups", error);
    }
  };

  const fetchTrash = async () => {
    try {
      const response = await api.get(`/admin/trash?page=${trashPage}&limit=${ITEMS_PER_PAGE}`);
      const files = response.data.files.map((f: any) => ({ ...f, type: "file" as const }));
      const folders = response.data.folders.map((f: any) => ({ ...f, type: "folder" as const }));
      setTrashItems([...folders, ...files]);
      setTrashTotal(response.data.fileTotal + response.data.folderTotal);
    } catch (error) {
      console.error("Failed to fetch trash", error);
    }
  };

  const fetchDepartments = async () => {
    try {
      const response = await api.get("/departments");
      setDepartments(response.data.departments);
    } catch (error) {
      console.error("Failed to fetch departments", error);
    }
  };

  const loadData = async () => {
    setIsLoading(true);
    if (activeTab === "users" || activeTab === "passwords") await fetchUsers();
    if (activeTab === "approvals") await fetchPendingFiles();
    if (activeTab === "maintenance") {
      await fetchMetrics();
      await fetchBackups();
    }
    if (activeTab === "trash") await fetchTrash();
    if (activeTab === "departments") await fetchDepartments();
    setIsLoading(false);
  };

  useEffect(() => {
    loadData();
  }, [activeTab, userPage, pendingPage, trashPage]);

  const handleStatusUpdate = async (fileId: number, status: 'approved' | 'rejected') => {
    try {
      await api.put(`/files/${fileId}/status`, { status });
      fetchPendingFiles();
    } catch (error) {
      console.error("Failed to update status", error);
    }
  };

  const handleBackup = async () => {
    try {
      const response = await api.get("/admin/backup", { responseType: 'blob' });
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `backup-${Date.now()}.sqlite`);
      document.body.appendChild(link);
      link.click();
      fetchBackups();
    } catch (error) {
      console.error("Backup failed", error);
    }
  };

  const handleRestore = async (type: "file" | "folder", id: number) => {
    try {
      await api.post(`/admin/trash/restore/${type}/${id}`);
      await fetchTrash();
    } catch (error: any) {
      console.error("Restore failed", error);
      alert(error.response?.data?.error || "Failed to restore item. Please try again.");
    }
  };

  const handlePermanentDelete = async (type: "file" | "folder", id: number) => {
    console.log(`handlePermanentDelete called for ${type} with id: ${id}`);
    setConfirmConfig({
      isOpen: true,
      title: "Permanent Delete",
      message: "Are you sure you want to permanently delete this item? This action cannot be undone and the file will be removed from the server.",
      onConfirm: async () => {
        console.log(`onConfirm triggered for permanent delete of ${type} id: ${id}`);
        try {
          const response = await api.delete(`/admin/trash/permanent/${type}/${id}`);
          console.log("Permanent delete response:", response.data);
          await fetchTrash();
        } catch (error: any) {
          console.error("Permanent delete failed", error);
          alert(error.response?.data?.error || "Failed to permanently delete item. Please try again.");
        }
      },
    });
  };

  const handleDeptSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingDept) {
        await api.put(`/departments/${editingDept.id}`, deptFormData);
      } else {
        await api.post("/departments", deptFormData);
      }
      setIsDeptModalOpen(false);
      setEditingDept(null);
      setDeptFormData({ name: "", description: "" });
      fetchDepartments();
    } catch (err: any) {
      console.error("Failed to save department", err);
      alert(err.response?.data?.error || "Error saving department.");
    }
  };

  const handleDeleteDept = async (id: number) => {
    setConfirmConfig({
      isOpen: true,
      title: "Delete Department",
      message: "Are you sure you want to delete this department?",
      onConfirm: async () => {
        try {
          await api.delete(`/departments/${id}`);
          await fetchDepartments();
        } catch (error: any) {
          console.error("Failed to delete department", error);
          alert(error.response?.data?.error || "Failed to delete department.");
        }
      },
    });
  };

  const openEditDeptModal = (dept: Department) => {
    setEditingDept(dept);
    setDeptFormData({
      name: dept.name,
      description: dept.description || "",
    });
    setIsDeptModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    try {
      if (editingUser) {
        await api.put(`/users/${editingUser.id}`, formData);
      } else {
        await api.post("/users", formData);
      }
      setIsModalOpen(false);
      setEditingUser(null);
      setFormData({ email: "", name: "", role: "employee", department: "", phone: "", password: "" });
      fetchUsers();
    } catch (err: any) {
      console.error("Failed to save user", err);
      setError(err.response?.data?.error || "Error saving user. Email might already exist.");
    }
  };

  const handleDelete = async (id: number) => {
    setConfirmConfig({
      isOpen: true,
      title: "Delete User",
      message: "Are you sure you want to delete this user? All their files and folders will be permanently removed. This action cannot be undone.",
      onConfirm: async () => {
        try {
          await api.delete(`/users/${id}`);
          await fetchUsers();
        } catch (error: any) {
          console.error("Failed to delete user", error);
          alert(error.response?.data?.error || "Failed to delete user. Please try again.");
        }
      },
    });
  };

  const openEditModal = (user: UserData) => {
    setEditingUser(user);
    setError("");
    setFormData({
      email: user.email,
      name: user.name,
      father_name: user.father_name || "",
      grandfather_name: user.grandfather_name || "",
      role: user.role,
      department: user.department || "",
      phone: user.phone || "",
      password: "", // Don't show password
    });
    setIsModalOpen(true);
  };

  const filteredUsers = users.filter(
    (u) =>
      u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (u.phone && u.phone.includes(searchQuery))
  );

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resettingUser || !newPassword) return;

    if (newPassword !== confirmPassword) {
      alert("Passwords do not match.");
      return;
    }
    
    try {
      await api.post(`/users/${resettingUser.id}/reset-password`, { newPassword });
      setIsResetModalOpen(false);
      setResettingUser(null);
      setNewPassword("");
      setConfirmPassword("");
      alert("Password reset successfully.");
    } catch (err: any) {
      console.error("Failed to reset password", err);
      alert(err.response?.data?.error || "Error resetting password.");
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Admin Control Center</h1>
          <p className="text-slate-500 text-sm mt-1">System maintenance, approvals, and user management</p>
        </div>

        <div className="flex items-center space-x-2 bg-slate-100 p-1 rounded-xl">
          <button
            onClick={() => setActiveTab("users")}
            className={cn(
              "px-4 py-2 rounded-lg text-sm font-medium transition-all",
              activeTab === "users" ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
            )}
          >
            Users
          </button>
          <button
            onClick={() => setActiveTab("passwords")}
            className={cn(
              "px-4 py-2 rounded-lg text-sm font-medium transition-all",
              activeTab === "passwords" ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
            )}
          >
            Reset Password
          </button>
          {currentUser?.role === "super_admin" && (
            <button
              onClick={() => setActiveTab("approvals")}
              className={cn(
                "px-4 py-2 rounded-lg text-sm font-medium transition-all",
                activeTab === "approvals" ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
              )}
            >
              Approvals
            </button>
          )}
          <button
            onClick={() => setActiveTab("trash")}
            className={cn(
              "px-4 py-2 rounded-lg text-sm font-medium transition-all",
              activeTab === "trash" ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
            )}
          >
            Trash
          </button>
        </div>
      </div>

      {activeTab === "users" && (
        <>
          <div className="flex justify-end mb-4">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search users..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all w-full md:w-64"
                />
              </div>
              <button
                onClick={() => {
                  setEditingUser(null);
                  setError("");
                  setFormData({ email: "", name: "", father_name: "", grandfather_name: "", role: "employee", department: "", phone: "", password: "" });
                  setIsModalOpen(true);
                }}
                className="flex items-center space-x-2 px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all text-sm font-medium shadow-lg shadow-indigo-100"
              >
                <UserPlus className="h-4 w-4" />
                <span>Add User</span>
              </button>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-20">
                <Loader2 className="h-10 w-10 text-indigo-600 animate-spin" />
              </div>
            ) : (
              <>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200">
                        <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">User</th>
                        <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Role</th>
                        <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Department</th>
                        <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Phone</th>
                        <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Joined</th>
                        <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredUsers.map((u) => (
                        <tr key={u.id} className="hover:bg-slate-50/50 transition-colors">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center space-x-3">
                              <div className="h-10 w-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-500">
                                <User className="h-5 w-5" />
                              </div>
                              <div className="flex flex-col">
                                <span className="text-sm font-semibold text-slate-900">{u.name} {u.father_name} {u.grandfather_name}</span>
                                <span className="text-xs text-slate-500">{u.email}</span>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span
                              className={cn(
                                "px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                                u.role === "super_admin"
                                  ? "bg-amber-100 text-amber-700 border border-amber-200"
                                  : u.role === "admin"
                                  ? "bg-purple-100 text-purple-700 border border-purple-200"
                                  : "bg-blue-100 text-blue-700 border border-blue-200"
                              )}
                            >
                              {u.role === "super_admin" ? "Super Admin" : u.role}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                            {u.department || "N/A"}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                            {u.phone || "N/A"}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                            {new Date(u.created_at).toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right">
                            <div className="flex items-center justify-end space-x-1">
                              <button
                                onClick={() => {
                                  setResettingUser(u);
                                  setIsResetModalOpen(true);
                                }}
                                title="Reset Password"
                                className="p-2 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-all"
                              >
                                <RotateCcw className="h-4 w-4" />
                              </button>
                              <button
                                onClick={() => openEditModal(u)}
                                className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                              >
                                <Edit2 className="h-4 w-4" />
                              </button>
                              <button
                                onClick={() => handleDelete(u.id)}
                                className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <Pagination
                  currentPage={userPage}
                  totalItems={userTotal}
                  itemsPerPage={ITEMS_PER_PAGE}
                  onPageChange={setUserPage}
                  className="border-t border-slate-100"
                />
              </>
            )}
          </div>
        </>
      )}

      {activeTab === "passwords" && (
        <>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-bold text-slate-900">Administrative Password Reset</h2>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search by name, email, or phone..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all w-full md:w-80"
              />
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-20">
                <Loader2 className="h-10 w-10 text-indigo-600 animate-spin" />
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200">
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">User</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Contact Info</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Department</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredUsers.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="px-6 py-10 text-center text-slate-500">
                          No users found matching your search.
                        </td>
                      </tr>
                    ) : (
                      filteredUsers.map((u) => (
                        <tr key={u.id} className="hover:bg-slate-50/50 transition-colors">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center space-x-3">
                              <div className="h-10 w-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 font-bold">
                                {u.name.charAt(0)}
                              </div>
                              <div className="flex flex-col">
                                <span className="text-sm font-semibold text-slate-900">{u.name} {u.father_name}</span>
                                <span className="text-xs text-slate-500 capitalize">{u.role.replace('_', ' ')}</span>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex flex-col space-y-1">
                              <div className="flex items-center text-xs text-slate-600">
                                <Mail className="h-3 w-3 mr-1.5" />
                                {u.email}
                              </div>
                              {u.phone && (
                                <div className="flex items-center text-xs text-slate-600">
                                  <Activity className="h-3 w-3 mr-1.5" />
                                  {u.phone}
                                </div>
                              )}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                            {u.department || "N/A"}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right">
                            <button
                              onClick={() => {
                                setResettingUser(u);
                                setIsResetModalOpen(true);
                              }}
                              className="inline-flex items-center space-x-2 px-4 py-2 bg-amber-50 text-amber-700 border border-amber-200 rounded-xl hover:bg-amber-100 transition-all text-xs font-bold uppercase tracking-wider"
                            >
                              <RotateCcw className="h-3.5 w-3.5" />
                              <span>Reset Password</span>
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}

      {activeTab === "departments" && currentUser?.role === "super_admin" && (
        <>
          <div className="flex justify-end mb-4">
            <button
              onClick={() => {
                setEditingDept(null);
                setDeptFormData({ name: "", description: "" });
                setIsDeptModalOpen(true);
              }}
              className="flex items-center space-x-2 px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all text-sm font-medium shadow-lg shadow-indigo-100"
            >
              <Building2 className="h-4 w-4" />
              <span>Add Department</span>
            </button>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-20">
                <Loader2 className="h-10 w-10 text-indigo-600 animate-spin" />
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200">
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Department Name</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Description</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Created At</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {departments.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="px-6 py-10 text-center text-slate-500">
                          No departments found.
                        </td>
                      </tr>
                    ) : (
                      departments.map((dept) => (
                        <tr key={dept.id} className="hover:bg-slate-50/50 transition-colors">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center space-x-3">
                              <div className="h-10 w-10 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600">
                                <Building2 className="h-5 w-5" />
                              </div>
                              <span className="text-sm font-semibold text-slate-900">{dept.name}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 text-sm text-slate-500 max-w-xs truncate">
                            {dept.description || "No description"}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                            {new Date(dept.created_at).toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right">
                            <div className="flex items-center justify-end space-x-1">
                              <button
                                onClick={() => openEditDeptModal(dept)}
                                className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                              >
                                <Edit2 className="h-4 w-4" />
                              </button>
                              <button
                                onClick={() => handleDeleteDept(dept.id)}
                                className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}

      {activeTab === "approvals" && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-20">
              <Loader2 className="h-10 w-10 text-indigo-600 animate-spin" />
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200">
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Document</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Description</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Owner</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Role</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Department</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Date</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {pendingFiles.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="px-6 py-10 text-center text-slate-500">
                          No pending documents for approval
                        </td>
                      </tr>
                    ) : (
                      pendingFiles.map((file) => (
                        <tr key={file.id} className="hover:bg-slate-50/50 transition-colors">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center space-x-3">
                              <div className="p-2 bg-amber-50 rounded-lg">
                                <Clock className="h-4 w-4 text-amber-600" />
                              </div>
                              <span className="text-sm font-medium text-slate-900">{file.original_name}</span>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 max-w-[200px] truncate">
                            {file.description || <span className="text-slate-300 italic">No description</span>}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">{file.owner_name}</td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={cn(
                              "px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border",
                              file.owner_role === 'admin' ? "bg-purple-50 text-purple-700 border-purple-200" : "bg-blue-50 text-blue-700 border-blue-200"
                            )}>
                              {file.owner_role}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">{file.department}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                            {new Date(file.created_at).toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right">
                            <div className="flex items-center justify-end space-x-2">
                              <button
                                onClick={() => handleStatusUpdate(file.id, 'approved')}
                                className="flex items-center space-x-1 px-3 py-1.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-lg hover:bg-emerald-100 transition-all text-xs font-bold uppercase tracking-wider"
                              >
                                <Check className="h-3 w-3" />
                                <span>Approve</span>
                              </button>
                              <button
                                onClick={() => handleStatusUpdate(file.id, 'rejected')}
                                className="flex items-center space-x-1 px-3 py-1.5 bg-red-50 text-red-700 border border-red-200 rounded-lg hover:bg-red-100 transition-all text-xs font-bold uppercase tracking-wider"
                              >
                                <Check className="h-3 w-3" />
                                <span>Reject</span>
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
              <Pagination
                currentPage={pendingPage}
                totalItems={pendingTotal}
                itemsPerPage={ITEMS_PER_PAGE}
                onPageChange={setPendingPage}
                className="border-t border-slate-100"
              />
            </>
          )}
        </div>
      )}

      {activeTab === "maintenance" && (
        <div className="space-y-6">
          <div className="max-w-2xl mx-auto">
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
              <div className="flex items-center space-x-3 mb-4">
                <div className="p-2 bg-amber-50 rounded-lg">
                  <Clock className="h-5 w-5 text-amber-600" />
                </div>
                <h3 className="font-bold text-slate-900">Recent Backups</h3>
              </div>
              <div className="space-y-3 max-h-60 overflow-y-auto">
                {backups.length === 0 ? (
                  <p className="text-sm text-slate-500 text-center py-4">No backups yet</p>
                ) : (
                  backups.map((b) => (
                    <div key={b.id} className="flex flex-col space-y-1 border-b border-slate-100 pb-2">
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-600 font-medium truncate max-w-[150px]" title={b.filename}>{b.filename}</span>
                        <span className="text-slate-400">{new Date(b.created_at).toLocaleDateString()}</span>
                      </div>
                      <div className="flex justify-between text-[10px] text-slate-400">
                        <span>By: {b.created_by_email || "System"}</span>
                        <span>{(b.size / 1024 / 1024).toFixed(2)} MB</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
              <button
                onClick={handleBackup}
                className="w-full mt-6 flex items-center justify-center space-x-2 px-4 py-2 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 transition-all text-sm font-medium"
              >
                <Download className="h-4 w-4" />
                <span>Trigger New Backup</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {activeTab === "trash" && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-20">
              <Loader2 className="h-10 w-10 text-indigo-600 animate-spin" />
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200">
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Item</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Type</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Deleted By</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Deleted At</th>
                      <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {trashItems.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="px-6 py-10 text-center text-slate-500">
                          Trash is empty
                        </td>
                      </tr>
                    ) : (
                      trashItems.map((item) => (
                        <tr key={`${item.type}-${item.id}`} className="hover:bg-slate-50/50 transition-colors">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className="text-sm font-medium text-slate-900">
                              {item.type === "file" ? item.original_name : item.name}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={cn(
                              "px-2 py-0.5 rounded text-[10px] font-bold uppercase",
                              item.type === "file" ? "bg-blue-50 text-blue-600" : "bg-amber-50 text-amber-600"
                            )}>
                              {item.type}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">
                            {item.deleted_by_email || "System"}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                            {new Date(item.deleted_at).toLocaleString()}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right">
                            <div className="flex items-center justify-end space-x-2">
                              <button
                                onClick={() => handleRestore(item.type, item.id)}
                                className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                                title="Restore"
                              >
                                <RotateCcw className="h-4 w-4" />
                              </button>
                              <button
                                onClick={() => handlePermanentDelete(item.type, item.id)}
                                className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                                title="Delete Permanently"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
              <Pagination
                currentPage={trashPage}
                totalItems={trashTotal}
                itemsPerPage={ITEMS_PER_PAGE}
                onPageChange={setTrashPage}
                className="border-t border-slate-100"
              />
            </>
          )}
        </div>
      )}

      {/* Reset Password Modal */}
      <AnimatePresence>
        {isResetModalOpen && resettingUser && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsResetModalOpen(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 overflow-hidden"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-900">Reset Password</h3>
                <button
                  onClick={() => setIsResetModalOpen(false)}
                  className="p-2 text-slate-400 hover:text-slate-600 rounded-full transition-colors"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="mb-6 p-4 bg-amber-50 rounded-xl border border-amber-100">
                <p className="text-sm text-amber-800">
                  You are resetting the password for <strong>{resettingUser.name}</strong> ({resettingUser.email}).
                </p>
                <p className="text-xs text-amber-700 mt-2">
                  The user will be forced to change this password on their next login.
                </p>
              </div>

              <form onSubmit={handleResetPassword} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">New Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <input
                      type="password"
                      required
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="block w-full pl-10 pr-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-slate-900"
                      placeholder="Enter new password"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Confirm Password</label>
                  <div className="relative">
                    <Check className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <input
                      type="password"
                      required
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="block w-full pl-10 pr-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-slate-900"
                      placeholder="Confirm new password"
                    />
                  </div>
                </div>

                <div className="flex space-x-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setIsResetModalOpen(false)}
                    className="flex-1 px-4 py-3 border border-slate-200 text-slate-700 font-semibold rounded-xl hover:bg-slate-50 transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 px-4 py-3 bg-amber-600 text-white font-semibold rounded-xl hover:bg-amber-700 transition-all shadow-lg shadow-amber-100 flex items-center justify-center space-x-2"
                  >
                    <RotateCcw className="h-4 w-4" />
                    <span>Reset Password</span>
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* User Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsModalOpen(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 overflow-hidden"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-900">
                  {editingUser ? "Edit User" : "Create New User"}
                </h3>
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="p-2 text-slate-400 hover:text-slate-600 rounded-full transition-colors"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                {error && (
                  <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded-md flex items-start space-x-3">
                    <ShieldAlert className="h-5 w-5 text-red-500 shrink-0" />
                    <p className="text-sm text-red-700">{error}</p>
                  </div>
                )}
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">First Name</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="block w-full pl-10 pr-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-slate-900"
                      placeholder="First Name"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Father's Name</label>
                    <input
                      type="text"
                      value={formData.father_name}
                      onChange={(e) => setFormData({ ...formData, father_name: e.target.value })}
                      className="block w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-slate-900"
                      placeholder="Father's Name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Grandfather's Name</label>
                    <input
                      type="text"
                      value={formData.grandfather_name}
                      onChange={(e) => setFormData({ ...formData, grandfather_name: e.target.value })}
                      className="block w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-slate-900"
                      placeholder="Grandfather's Name"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="block w-full pl-10 pr-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-slate-900"
                      placeholder="john@gmail.com"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Role</label>
                  <div className={cn(
                    "grid gap-3",
                    currentUser?.role === "super_admin" ? "grid-cols-3" : "grid-cols-2"
                  )}>
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, role: "employee" })}
                      className={cn(
                        "flex items-center justify-center space-x-2 p-3 rounded-xl border transition-all",
                        formData.role === "employee"
                          ? "bg-indigo-50 border-indigo-200 text-indigo-700 ring-2 ring-indigo-500/20"
                          : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                      )}
                    >
                      <Shield className="h-4 w-4" />
                      <span className="text-sm font-medium">Employee</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, role: "admin" })}
                      className={cn(
                        "flex items-center justify-center space-x-2 p-3 rounded-xl border transition-all",
                        formData.role === "admin"
                          ? "bg-purple-50 border-purple-200 text-purple-700 ring-2 ring-purple-500/20"
                          : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                      )}
                    >
                      <ShieldAlert className="h-4 w-4" />
                      <span className="text-sm font-medium">Admin</span>
                    </button>
                    {currentUser?.role === "super_admin" && (
                      <button
                        type="button"
                        onClick={() => setFormData({ ...formData, role: "super_admin" })}
                        className={cn(
                          "flex items-center justify-center space-x-2 p-3 rounded-xl border transition-all",
                          formData.role === "super_admin"
                            ? "bg-amber-50 border-amber-200 text-amber-700 ring-2 ring-amber-500/20"
                            : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                        )}
                      >
                        <ShieldAlert className="h-4 w-4" />
                        <span className="text-sm font-medium">Super</span>
                      </button>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Department</label>
                    {departments.length > 0 ? (
                      <select
                        value={formData.department}
                        onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                        className="block w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-slate-900 bg-white"
                      >
                        <option value="">Select Department</option>
                        {departments.map((d) => (
                          <option key={d.id} value={d.name}>{d.name}</option>
                        ))}
                      </select>
                    ) : (
                      <input
                        type="text"
                        value={formData.department}
                        onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                        className="block w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-slate-900"
                        placeholder="Engineering, HR, etc."
                      />
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Phone Number</label>
                    <div className="flex">
                      <span className="inline-flex items-center px-4 py-2.5 rounded-l-xl border border-r-0 border-slate-200 bg-slate-50 text-slate-500 text-sm font-medium">
                        +251
                      </span>
                      <input
                        type="text"
                        maxLength={9}
                        value={formData.phone.replace("+251", "")}
                        onChange={(e) => {
                          const val = e.target.value.replace(/\D/g, "");
                          if (val.length <= 9) {
                            setFormData({ ...formData, phone: val ? `+251${val}` : "" });
                          }
                        }}
                        className="block w-full px-4 py-2.5 border border-slate-200 rounded-r-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-slate-900"
                        placeholder="911223344"
                      />
                    </div>
                    <p className="text-[10px] text-slate-400 mt-1">Enter the 9 digits after +251</p>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    {editingUser ? "New Password (leave blank to keep current)" : "Password"}
                  </label>
                  <input
                    type="password"
                    required={!editingUser}
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className="block w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-slate-900"
                    placeholder="••••••••"
                  />
                </div>

                <div className="flex space-x-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="flex-1 px-4 py-3 border border-slate-200 text-slate-700 font-semibold rounded-xl hover:bg-slate-50 transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 px-4 py-3 bg-indigo-600 text-white font-semibold rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 flex items-center justify-center space-x-2"
                  >
                    <Check className="h-4 w-4" />
                    <span>{editingUser ? "Update User" : "Create User"}</span>
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Department Modal */}
      <AnimatePresence>
        {isDeptModalOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsDeptModalOpen(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 overflow-hidden"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-900">
                  {editingDept ? "Edit Department" : "Create New Department"}
                </h3>
                <button
                  onClick={() => setIsDeptModalOpen(false)}
                  className="p-2 text-slate-400 hover:text-slate-600 rounded-full transition-colors"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <form onSubmit={handleDeptSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Department Name</label>
                  <div className="relative">
                    <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <input
                      type="text"
                      required
                      value={deptFormData.name}
                      onChange={(e) => setDeptFormData({ ...deptFormData, name: e.target.value })}
                      className="block w-full pl-10 pr-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-slate-900"
                      placeholder="Engineering"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Description</label>
                  <textarea
                    value={deptFormData.description}
                    onChange={(e) => setDeptFormData({ ...deptFormData, description: e.target.value })}
                    className="block w-full px-4 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-slate-900 h-24 resize-none"
                    placeholder="Department description..."
                  />
                </div>

                <div className="flex space-x-3 pt-4">
                  <button
                    type="button"
                    onClick={() => setIsDeptModalOpen(false)}
                    className="flex-1 px-4 py-3 border border-slate-200 text-slate-700 font-semibold rounded-xl hover:bg-slate-50 transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 px-4 py-3 bg-indigo-600 text-white font-semibold rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 flex items-center justify-center space-x-2"
                  >
                    <Check className="h-4 w-4" />
                    <span>{editingDept ? "Update" : "Create"}</span>
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <ConfirmModal
        isOpen={confirmConfig.isOpen}
        onClose={() => setConfirmConfig({ ...confirmConfig, isOpen: false })}
        onConfirm={confirmConfig.onConfirm}
        title={confirmConfig.title}
        message={confirmConfig.message}
      />
    </div>
  );
};

export default AdminDashboard;
