import React, { useState, useEffect, useCallback } from "react";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";
import { cn } from "../utils/cn";
import {
  Folder,
  File,
  Plus,
  Upload,
  Trash2,
  Download,
  ChevronRight,
  Home,
  MoreVertical,
  Search,
  FileText,
  Image as ImageIcon,
  Music,
  Video,
  Archive,
  X,
  Loader2,
  FolderOpen,
  Edit2,
  BarChart3,
  PieChart as PieChartIcon,
  Users,
  Share2,
  Lock,
  Unlock
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import Pagination from "../components/Pagination";
import ShareModal from "../components/ShareModal";
import { useToast } from "../context/ToastContext";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie,
} from "recharts";
import ConfirmModal from "../components/ConfirmModal";

interface FolderData {
  id: number;
  name: string;
  parent_id: number | null;
  user_id: number;
  department?: string;
  is_locked?: number;
  created_at: string;
}

interface FileData {
  id: number;
  name: string;
  original_name: string;
  mime_type: string;
  size: number;
  path: string;
  folder_id: number | null;
  user_id: number;
  owner_name: string;
  department?: string;
  description?: string;
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
}

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const { showToast } = useToast();
  const [folders, setFolders] = useState<FolderData[]>([]);
  const [files, setFiles] = useState<FileData[]>([]);
  const [currentFolderId, setCurrentFolderId] = useState<number | null>(null);
  const [breadcrumbs, setBreadcrumbs] = useState<{ id: number | null; name: string }[]>([
    { id: null, name: "Home" },
  ]);
  const [isCreateFolderOpen, setIsCreateFolderOpen] = useState(false);
  const [newFolderName, setNewFolderName] = useState("");
  const [newFolderPassword, setNewFolderPassword] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<{ current: number; total: number } | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [confirmConfig, setConfirmConfig] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => Promise<void> | void;
  }>({
    isOpen: false,
    title: "",
    message: "",
    onConfirm: () => {},
  });
  const [isRenameOpen, setIsRenameOpen] = useState(false);
  const [renameTarget, setRenameTarget] = useState<{ id: number; name: string; type: "file" | "folder" } | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [fileDescription, setFileDescription] = useState("");
  const [newShares, setNewShares] = useState<any[]>([]);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [shareItem, setShareItem] = useState<{ id: number; name: string; type: "file" | "folder"; public_token?: string | null } | null>(null);
  const [isLockModalOpen, setIsLockModalOpen] = useState(false);
  const [lockTarget, setLockTarget] = useState<FolderData | null>(null);
  const [lockPassword, setLockPassword] = useState("");
  const [isUnlockPromptOpen, setIsUnlockPromptOpen] = useState(false);
  const [isPermanentUnlock, setIsPermanentUnlock] = useState(false);
  const [unlockTarget, setUnlockTarget] = useState<FolderData | null>(null);
  const [unlockPassword, setUnlockPassword] = useState("");
  const [activeTab, setActiveTab] = useState<"all" | "shared">("all");
  const [stats, setStats] = useState<any>(null);
  const [showStats, setShowStats] = useState(true);

  // Pagination state
  const [folderPage, setFolderPage] = useState(1);
  const [folderTotal, setFolderTotal] = useState(0);
  const [filePage, setFilePage] = useState(1);
  const [fileTotal, setFileTotal] = useState(0);
  const ITEMS_PER_PAGE = 10;

  const fetchData = useCallback(async () => {
    setIsLoading(true);
    try {
      if (activeTab === "shared") {
        const [sharedRes, statsRes] = await Promise.all([
          api.get("/shared-with-me"),
          api.get("/stats")
        ]);
        
        const sharedFolders = sharedRes.data
          .filter((s: any) => s.item_type === "folder")
          .map((s: any) => ({
            id: s.item_id,
            name: s.name,
            user_id: s.shared_by,
            created_at: s.created_at,
            owner_name: s.shared_by_name
          }));
          
        const sharedFiles = sharedRes.data
          .filter((s: any) => s.item_type === "file")
          .map((s: any) => ({
            id: s.item_id,
            original_name: s.name,
            mime_type: s.type,
            size: s.size,
            user_id: s.shared_by,
            owner_name: s.shared_by_name,
            created_at: s.created_at,
            status: 'approved'
          }));

        setFolders(sharedFolders);
        setFolderTotal(sharedFolders.length);
        setFiles(sharedFiles);
        setFileTotal(sharedFiles.length);
        setStats(statsRes.data);
      } else {
        const [foldersRes, filesRes, statsRes] = await Promise.all([
          api.get(`/folders?parentId=${currentFolderId || ""}&page=${folderPage}&limit=${ITEMS_PER_PAGE}`),
          api.get(`/files?folderId=${currentFolderId || ""}&page=${filePage}&limit=${ITEMS_PER_PAGE}`),
          api.get("/stats")
        ]);
        setFolders(foldersRes.data.folders);
        setFolderTotal(foldersRes.data.total);
        setFiles(filesRes.data.files);
        setFileTotal(filesRes.data.total);
        setStats(statsRes.data);
      }
    } catch (error: any) {
      console.error("Failed to fetch data", error);
      if (error.response?.status === 403) {
        showToast("You don't have permission to access this folder", "error");
        // If we were trying to enter a folder, go back
        if (breadcrumbs.length > 1) {
          const prevCrumb = breadcrumbs[breadcrumbs.length - 2];
          setCurrentFolderId(prevCrumb.id);
          setBreadcrumbs(breadcrumbs.slice(0, breadcrumbs.length - 1));
        } else {
          setCurrentFolderId(null);
          setBreadcrumbs([{ id: null, name: "Home" }]);
        }
      } else {
        showToast("Failed to load content. Please try again.", "error");
      }
    } finally {
      setIsLoading(false);
    }
  }, [currentFolderId, folderPage, filePage, activeTab]);

  useEffect(() => {
    // Reset pages when folder changes
    setFolderPage(1);
    setFilePage(1);
  }, [currentFolderId]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  useEffect(() => {
    const checkNewShares = async () => {
      try {
        const response = await api.get("/shared-with-me?newOnly=true");
        if (response.data.length > 0) {
          setNewShares(response.data);
          response.data.forEach((share: any) => {
            showToast(`${share.shared_by_name} shared a ${share.item_type}: ${share.name}`, "info");
          });
        }
      } catch (error) {
        console.error("Failed to check new shares", error);
      }
    };
    checkNewShares();
  }, [showToast]);

  const markSharesAsNotified = async () => {
    if (newShares.length === 0) return;
    try {
      const ids = newShares.map((s: any) => s.id);
      await api.post("/shares/mark-notified", { ids });
      setNewShares([]);
    } catch (error) {
      console.error("Failed to mark shares as notified", error);
    }
  };

  const handleCreateFolder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFolderName.trim()) return;

    try {
      await api.post("/folders", { 
        name: newFolderName, 
        parentId: currentFolderId,
        password: newFolderPassword
      });
      setNewFolderName("");
      setNewFolderPassword("");
      setIsCreateFolderOpen(false);
      showToast("Folder created successfully", "success");
      fetchData();
    } catch (error: any) {
      console.error("Failed to create folder", error);
      showToast(error.response?.data?.error || "Failed to create folder. Please try again.", "error");
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const filesList = e.target.files;
    if (!filesList || filesList.length === 0) return;
    setSelectedFiles(Array.from(filesList));
    setFileDescription("");
    setIsUploadModalOpen(true);
    // Reset input so the same file can be selected again if needed
    e.target.value = "";
  };

  const handleFileUpload = async () => {
    if (selectedFiles.length === 0) return;

    setIsUploading(true);
    setIsUploadModalOpen(false);
    setUploadProgress({ current: 0, total: selectedFiles.length });
    
    try {
      let count = 0;
      for (const file of selectedFiles) {
        count++;
        setUploadProgress({ current: count, total: selectedFiles.length });
        const formData = new FormData();
        if (currentFolderId !== null) {
          formData.append("folderId", currentFolderId.toString());
        }
        formData.append("file", file);
        if (fileDescription.trim()) {
          formData.append("description", fileDescription.trim());
        }
        await api.post("/files/upload", formData);
      }
      
      showToast(`${selectedFiles.length} file(s) uploaded successfully`, "success");
      setSelectedFiles([]);
      setFileDescription("");

      // Calculate the new last page and navigate to it
      const newTotal = fileTotal + selectedFiles.length;
      const lastPage = Math.ceil(newTotal / ITEMS_PER_PAGE);
      if (lastPage > filePage) {
        setFilePage(lastPage);
      } else {
        fetchData();
      }
    } catch (error: any) {
      console.error("Upload failed", error);
      showToast(error.response?.data?.error || "Some uploads failed. Please try again.", "error");
      fetchData(); // Refresh to show what was uploaded
    } finally {
      setIsUploading(false);
      setUploadProgress(null);
    }
  };

  const handleDeleteFile = useCallback((id: number) => {
    console.log("Dashboard: handleDeleteFile called with id:", id);
    setConfirmConfig({
      isOpen: true,
      title: "Move to Trash",
      message: "Are you sure you want to delete this file? It will be moved to the trash and can be recovered by an administrator.",
      onConfirm: async () => {
        console.log("Dashboard: onConfirm triggered for file id:", id);
        try {
          const response = await api.delete(`/files/${id}`);
          console.log("Dashboard: Delete response:", response.data);
          // Close modal immediately upon success
          setConfirmConfig(prev => ({ ...prev, isOpen: false }));
          showToast("File moved to trash", "success");
          // Refresh data in background
          fetchData();
        } catch (error: any) {
          console.error("Dashboard: Delete failed", error);
          const errorMsg = error.response?.data?.error || "Failed to delete file. Please try again.";
          showToast(errorMsg, "error");
          // Close modal on error too to prevent "Processing" hang
          setConfirmConfig(prev => ({ ...prev, isOpen: false }));
        }
      },
    });
  }, [fetchData]);

  const handleDeleteFolder = useCallback((id: number) => {
    console.log("Dashboard: handleDeleteFolder called with id:", id);
    setConfirmConfig({
      isOpen: true,
      title: "Move to Trash",
      message: "Are you sure you want to delete this folder and all its contents? They will be moved to the trash and can be recovered by an administrator.",
      onConfirm: async () => {
        console.log("Dashboard: onConfirm triggered for folder id:", id);
        try {
          const response = await api.delete(`/folders/${id}`);
          console.log("Dashboard: Delete response:", response.data);
          // Close modal immediately upon success
          setConfirmConfig(prev => ({ ...prev, isOpen: false }));
          showToast("Folder moved to trash", "success");
          // Refresh data in background
          fetchData();
        } catch (error: any) {
          console.error("Dashboard: Delete failed", error);
          const errorMsg = error.response?.data?.error || "Failed to delete folder. Please try again.";
          showToast(errorMsg, "error");
          // Close modal on error too to prevent "Processing" hang
          setConfirmConfig(prev => ({ ...prev, isOpen: false }));
        }
      },
    });
  }, [fetchData]);

  const handleRename = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!renameTarget || !renameValue.trim()) return;

    try {
      if (renameTarget.type === "folder") {
        await api.put(`/folders/${renameTarget.id}`, { name: renameValue });
      } else {
        await api.put(`/files/${renameTarget.id}`, { name: renameValue });
      }
      setIsRenameOpen(false);
      setRenameTarget(null);
      setRenameValue("");
      showToast("Renamed successfully", "success");
      fetchData();
    } catch (error: any) {
      console.error("Rename failed", error);
      showToast(error.response?.data?.error || "Failed to rename. Please try again.", "error");
    }
  };

  const openRenameModal = (id: number, name: string, type: "file" | "folder") => {
    setRenameTarget({ id, name, type });
    setRenameValue(name);
    setIsRenameOpen(true);
  };

  const openShareModal = (id: number, name: string, type: "file" | "folder", public_token?: string | null) => {
    setShareItem({ id, name, type, public_token });
    setIsShareModalOpen(true);
  };

  const handleDownload = async (id: number, filename: string) => {
    try {
      const response = await api.get(`/files/download/${id}`, { responseType: "blob" });
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", filename);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      console.error("Download failed", error);
    }
  };

  const handleLockFolder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!lockTarget) return;

    try {
      await api.post(`/folders/${lockTarget.id}/lock`, { password: lockPassword });
      setIsLockModalOpen(false);
      setLockTarget(null);
      setLockPassword("");
      showToast("Folder locked successfully", "success");
      fetchData();
    } catch (error: any) {
      console.error("Lock failed", error);
      showToast(error.response?.data?.error || "Failed to lock folder", "error");
    }
  };

  const handleVerifyAndNavigate = async (folder: FolderData) => {
    if (folder.is_locked) {
      setUnlockTarget(folder);
      setIsPermanentUnlock(false);
      setIsUnlockPromptOpen(true);
      return;
    }
    navigateToFolder(folder);
  };

  const handleUnlockAndNavigate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!unlockTarget) return;

    try {
      if (isPermanentUnlock && (unlockTarget.user_id === user?.id || user?.role === "super_admin")) {
        await api.post(`/folders/${unlockTarget.id}/unlock`, { password: unlockPassword });
        showToast("Folder unlocked successfully", "success");
        fetchData();
      } else {
        await api.post(`/folders/${unlockTarget.id}/verify-lock`, { password: unlockPassword });
      }
      
      const target = unlockTarget;
      setIsUnlockPromptOpen(false);
      setUnlockTarget(null);
      setUnlockPassword("");
      if (!isPermanentUnlock) {
        navigateToFolder(target);
      }
    } catch (error: any) {
      console.error("Verification failed", error);
      showToast(error.response?.data?.error || "Invalid password", "error");
    }
  };

  const navigateToFolder = (folder: FolderData | null) => {
    if (folder === null) {
      setCurrentFolderId(null);
      setBreadcrumbs([{ id: null, name: "Home" }]);
    } else {
      setCurrentFolderId(folder.id);
      if (activeTab === "shared") {
        setActiveTab("all");
      }
      // Update breadcrumbs
      const existingIdx = breadcrumbs.findIndex((b) => b.id === folder.id);
      if (existingIdx !== -1) {
        setBreadcrumbs(breadcrumbs.slice(0, existingIdx + 1));
      } else {
        setBreadcrumbs([...breadcrumbs, { id: folder.id, name: folder.name }]);
      }
    }
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB", "TB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  const getFileIcon = (mime: string) => {
    if (mime.startsWith("image/")) return <ImageIcon className="text-pink-500" />;
    if (mime.startsWith("video/")) return <Video className="text-purple-500" />;
    if (mime.startsWith("audio/")) return <Music className="text-yellow-500" />;
    if (mime.includes("pdf") || mime.includes("word") || mime.includes("text")) return <FileText className="text-blue-500" />;
    if (mime.includes("zip") || mime.includes("rar") || mime.includes("tar")) return <Archive className="text-orange-500" />;
    return <File className="text-slate-400" />;
  };

  const filteredFolders = folders.filter((f) => f.name.toLowerCase().includes(searchQuery.toLowerCase()));
  const filteredFiles = files.filter((f) => f.original_name.toLowerCase().includes(searchQuery.toLowerCase()));

  const chartData = stats ? [
    { name: 'Files', count: stats.files.count, color: '#6366f1' },
    { name: 'Folders', count: stats.folders.count, color: '#f59e0b' },
    { name: 'Users', count: stats.totalUsers.count, color: '#10b981' },
    { name: 'Admins', count: stats.users.find((u: any) => u.role === 'admin')?.count || 0, color: '#ef4444' },
    { name: 'Super Admins', count: stats.users.find((u: any) => u.role === 'super_admin')?.count || 0, color: '#8b5cf6' },
  ] : [];

  const userRoleData = stats ? stats.users.map((u: any) => ({
    name: u.role.split('_').map((word: string) => word.charAt(0).toUpperCase() + word.slice(1)).join(' '),
    value: u.count
  })) : [];

  const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ef4444'];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* New Shares Notification Banner */}
      <AnimatePresence>
        {newShares.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="mb-6 p-4 bg-indigo-600 rounded-2xl shadow-lg shadow-indigo-100 flex items-center justify-between text-white"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/20 rounded-xl">
                <Share2 className="h-5 w-5" />
              </div>
              <div>
                <p className="font-bold">New items shared with you!</p>
                <p className="text-xs text-indigo-100">
                  {newShares.length} new {newShares.length === 1 ? "item has" : "items have"} been shared with you.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setActiveTab("shared");
                  markSharesAsNotified();
                }}
                className="px-4 py-2 bg-white text-indigo-600 rounded-xl text-xs font-bold hover:bg-indigo-50 transition-colors"
              >
                View Shared Items
              </button>
              <button
                onClick={markSharesAsNotified}
                className="p-2 hover:bg-white/10 rounded-xl transition-colors"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Stats Section Toggle */}
      <div className="mb-6 flex justify-end">
        <button
          onClick={() => setShowStats(!showStats)}
          className="btn-secondary flex items-center space-x-2 text-sm"
        >
          {showStats ? <ChevronRight className="h-4 w-4 rotate-90" /> : <BarChart3 className="h-4 w-4" />}
          <span>{showStats ? "Hide Statistics" : "Show Statistics"}</span>
        </button>
      </div>

      <AnimatePresence>
        {showStats && stats && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden mb-8"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Resource Distribution */}
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider mb-6 flex items-center gap-2">
                  <div className="p-1.5 bg-indigo-50 rounded-lg">
                    <BarChart3 className="h-4 w-4 text-indigo-500" />
                  </div>
                  Resource Distribution
                </h3>
                <div className="h-[250px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                      <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                      <Tooltip 
                        contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                        cursor={{ fill: '#f8fafc' }}
                      />
                      <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                        {chartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* User Roles */}
              <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider mb-6 flex items-center gap-2">
                  <div className="p-1.5 bg-emerald-50 rounded-lg">
                    <Users className="h-4 w-4 text-emerald-500" />
                  </div>
                  User Roles
                </h3>
                <div className="h-[250px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={userRoleData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {userRoleData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip 
                        contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="flex justify-center gap-6 mt-2">
                    {userRoleData.map((entry, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                        <span className="text-xs text-slate-600 font-medium">{entry.name}: {entry.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-8 border-b border-slate-200 mb-6">
            <button
              onClick={() => setActiveTab("all")}
              className={cn(
                "pb-4 text-sm font-bold uppercase tracking-wider transition-all relative",
                activeTab === "all" ? "text-indigo-600" : "text-slate-400 hover:text-slate-600"
              )}
            >
              My Documents
              {activeTab === "all" && (
                <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-600" />
              )}
            </button>
            <button
              onClick={() => setActiveTab("shared")}
              className={cn(
                "pb-4 text-sm font-bold uppercase tracking-wider transition-all relative",
                activeTab === "shared" ? "text-indigo-600" : "text-slate-400 hover:text-slate-600"
              )}
            >
              Shared with me
              {activeTab === "shared" && (
                <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-600" />
              )}
            </button>
          </div>
          <nav className="flex items-center space-x-1 text-sm text-slate-500 mt-1">
            {breadcrumbs.map((crumb, idx) => (
              <React.Fragment key={idx}>
                {idx > 0 && <ChevronRight className="h-4 w-4 text-slate-300" />}
                <button
                  onClick={() => {
                    setCurrentFolderId(crumb.id);
                    setBreadcrumbs(breadcrumbs.slice(0, idx + 1));
                    if (crumb.id === null && activeTab === "shared") {
                      setActiveTab("all");
                    }
                  }}
                  className={cn(
                    "hover:text-indigo-600 transition-colors capitalize",
                    idx === breadcrumbs.length - 1 && "font-semibold text-slate-900"
                  )}
                >
                  {crumb.name}
                </button>
              </React.Fragment>
            ))}
          </nav>
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search files..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all w-full md:w-64"
            />
          </div>
          
          {activeTab === "all" && (
            <div className="flex items-center gap-3">
              <button
                onClick={() => setIsCreateFolderOpen(true)}
                className="flex-1 sm:flex-none flex items-center justify-center space-x-2 px-4 py-2 bg-white border border-slate-200 text-slate-700 rounded-xl hover:bg-slate-50 transition-all text-sm font-medium shadow-sm"
              >
                <Plus className="h-4 w-4" />
                <span>New Folder</span>
              </button>

              <label className="flex-1 sm:flex-none flex items-center justify-center space-x-2 px-4 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all text-sm font-medium cursor-pointer shadow-lg shadow-indigo-100">
                {isUploading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>{uploadProgress ? `Uploading ${uploadProgress.current}/${uploadProgress.total}` : "Uploading..."}</span>
                  </>
                ) : (
                  <>
                    <Upload className="h-4 w-4" />
                    <span>Upload File</span>
                  </>
                )}
                <input type="file" className="hidden" onChange={handleFileSelect} disabled={isUploading} multiple />
              </label>
            </div>
          )}
        </div>
      </div>

      {/* Upload Modal */}
      <AnimatePresence>
        {isUploadModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden"
            >
              <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                <h3 className="text-lg font-bold text-slate-900">Upload Files</h3>
                <button onClick={() => setIsUploadModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                  <X className="h-5 w-5" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Selected Files</label>
                  <div className="bg-slate-50 rounded-xl p-3 max-h-32 overflow-y-auto border border-slate-200">
                    {selectedFiles.map((file, idx) => (
                      <div key={idx} className="flex items-center gap-2 text-xs text-slate-600 mb-1 last:mb-0">
                        <File className="h-3 w-3 text-slate-400" />
                        <span className="truncate">{file.name}</span>
                        <span className="text-slate-400 ml-auto">{formatSize(file.size)}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">Description (Optional)</label>
                  <textarea
                    value={fileDescription}
                    onChange={(e) => setFileDescription(e.target.value)}
                    placeholder="Enter a description for these files..."
                    className="w-full px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all h-24 resize-none"
                  />
                </div>
              </div>
              <div className="p-6 bg-slate-50 flex justify-end gap-3">
                <button
                  onClick={() => setIsUploadModalOpen(false)}
                  className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  onClick={handleFileUpload}
                  className="px-6 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all text-sm font-bold shadow-lg shadow-indigo-100"
                >
                  Start Upload
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Lock Folder Modal */}
      <AnimatePresence>
        {isLockModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden"
            >
              <form onSubmit={handleLockFolder}>
                <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                  <h3 className="text-lg font-bold text-slate-900">Lock Folder</h3>
                  <button type="button" onClick={() => setIsLockModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                    <X className="h-5 w-5" />
                  </button>
                </div>
                <div className="p-6 space-y-4">
                  <p className="text-sm text-slate-500">
                    Locking this folder will hide it from other department members and require a password for access.
                  </p>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-2">Lock Password (Optional)</label>
                    <input
                      type="password"
                      value={lockPassword}
                      onChange={(e) => setLockPassword(e.target.value)}
                      placeholder="Enter password to lock..."
                      className="w-full px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all"
                    />
                    <p className="text-[10px] text-slate-400 mt-1">If you leave this empty, only you will be able to access it.</p>
                  </div>
                </div>
                <div className="p-6 bg-slate-50 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setIsLockModalOpen(false)}
                    className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-900"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all text-sm font-bold shadow-lg shadow-indigo-100"
                  >
                    Lock Folder
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Unlock Prompt Modal */}
      <AnimatePresence>
        {isUnlockPromptOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden"
            >
              <form onSubmit={handleUnlockAndNavigate}>
                <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                  <h3 className="text-lg font-bold text-slate-900">
                    {isPermanentUnlock ? "Unlock Folder" : "Enter Password"}
                  </h3>
                  <button type="button" onClick={() => setIsUnlockPromptOpen(false)} className="text-slate-400 hover:text-slate-600">
                    <X className="h-5 w-5" />
                  </button>
                </div>
                <div className="p-6 space-y-4">
                  <div className="flex items-center justify-center py-4">
                    <div className="p-4 bg-red-50 rounded-full">
                      <Lock className="h-8 w-8 text-red-500" />
                    </div>
                  </div>
                  <p className="text-sm text-center text-slate-600">
                    This folder is locked. Please enter the password to {isPermanentUnlock ? "permanently unlock" : "access"} it.
                  </p>
                  <div>
                    <input
                      type="password"
                      value={unlockPassword}
                      onChange={(e) => setUnlockPassword(e.target.value)}
                      placeholder="Enter password..."
                      autoFocus
                      className="w-full px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-slate-900"
                    />
                  </div>
                </div>
                <div className="p-6 bg-slate-50 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setIsUnlockPromptOpen(false)}
                    className="px-4 py-2 text-sm font-medium text-slate-600 hover:text-slate-900"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-all text-sm font-bold shadow-lg shadow-indigo-100"
                  >
                    {isPermanentUnlock ? "Unlock" : "Access"}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Content Area */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center py-20">
            <Loader2 className="h-10 w-10 text-indigo-600 animate-spin" />
            <p className="mt-4 text-slate-500 text-sm">Loading your files...</p>
          </div>
        ) : (filteredFolders.length === 0 && filteredFiles.length === 0) ? (
          <div className="flex flex-col items-center justify-center py-20 text-center px-4">
            <div className="bg-slate-50 p-6 rounded-full mb-4">
              <FolderOpen className="h-12 w-12 text-slate-300" />
            </div>
            <h3 className="text-lg font-semibold text-slate-900">No files found</h3>
            <p className="text-slate-500 max-w-xs mx-auto mt-1">
              {searchQuery ? `No results for "${searchQuery}"` : 
                "This folder is empty. Start by uploading a file or creating a folder."}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200">
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Name</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Description</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Size</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Owner</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Department</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Date</th>
                  <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {/* Folders */}
                {filteredFolders.map((folder) => (
                      <tr
                        key={`folder-${folder.id}`}
                        className="hover:bg-slate-50/50 transition-colors group cursor-pointer"
                        onClick={() => handleVerifyAndNavigate(folder)}
                      >
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center space-x-3">
                            <div className="p-2 bg-amber-50 rounded-lg relative">
                              <Folder className="h-5 w-5 text-amber-500 fill-amber-500" />
                              {folder.is_locked ? (
                                <div className="absolute -top-1 -right-1 bg-red-500 rounded-full p-0.5 border border-white">
                                  <Lock className="h-2 w-2 text-white" />
                                </div>
                              ) : null}
                            </div>
                            <span className="text-sm font-medium text-slate-900">{folder.name}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-400">--</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-400">--</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">Me</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                          {folder.department || "N/A"}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-600 border border-slate-200">
                            N/A
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-400">
                          {new Date(folder.created_at).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right">
                          <div className="flex items-center justify-end space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            {(user?.role === "admin" || user?.role === "super_admin" || folder.user_id === user?.id) && (
                              <>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    if (folder.is_locked) {
                                      setUnlockTarget(folder);
                                      setIsPermanentUnlock(true);
                                      setIsUnlockPromptOpen(true);
                                    } else {
                                      setLockTarget(folder);
                                      setIsLockModalOpen(true);
                                    }
                                  }}
                                  className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                                  title={folder.is_locked ? "Unlock" : "Lock"}
                                >
                                  {folder.is_locked ? <Unlock className="h-4 w-4" /> : <Lock className="h-4 w-4" />}
                                </button>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    openRenameModal(folder.id, folder.name, "folder");
                                  }}
                                  className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                                  title="Rename"
                                >
                                  <Edit2 className="h-4 w-4" />
                                </button>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    openShareModal(folder.id, folder.name, "folder", folder.public_token);
                                  }}
                                  className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                                  title="Share"
                                >
                                  <Share2 className="h-4 w-4" />
                                </button>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleDeleteFolder(folder.id);
                                  }}
                                  className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                                  title="Delete"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}

                    {/* Files */}
                    {filteredFiles.map((file) => (
                      <tr key={`file-${file.id}`} className="hover:bg-slate-50/50 transition-colors group">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center space-x-3">
                            <div className="p-2 bg-slate-50 rounded-lg">
                              {getFileIcon(file.mime_type)}
                            </div>
                            <div className="flex flex-col">
                              <span className="text-sm font-medium text-slate-900 truncate max-w-[200px]" title={file.original_name}>
                                {file.original_name}
                              </span>
                              <span className="text-[10px] text-slate-400 uppercase font-bold tracking-tight">
                                {file.mime_type.split("/")[1] || "file"}
                              </span>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 max-w-[200px] truncate">
                          {file.description || <span className="text-slate-300 italic">No description</span>}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">{formatSize(file.size)}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="text-xs font-medium px-2 py-1 bg-slate-100 text-slate-600 rounded-full">
                            {file.user_id === user?.id ? "Me" : file.owner_name}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                          {file.department || "N/A"}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={cn(
                            "px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border",
                            file.status === 'approved' ? "bg-emerald-50 text-emerald-700 border-emerald-200" :
                            file.status === 'rejected' ? "bg-red-50 text-red-700 border-red-200" :
                            "bg-amber-50 text-amber-700 border-amber-200"
                          )}>
                            {file.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-400">
                          {new Date(file.created_at).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right">
                          <div className="flex items-center justify-end space-x-1">
                            <button
                              onClick={() => handleDownload(file.id, file.original_name)}
                              className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                              title="Download"
                            >
                              <Download className="h-4 w-4" />
                            </button>
                            {(user?.role === "admin" || user?.role === "super_admin" || file.user_id === user?.id) && (
                              <>
                                <button
                                  onClick={() => openRenameModal(file.id, file.original_name, "file")}
                                  className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                                  title="Rename"
                                >
                                  <Edit2 className="h-4 w-4" />
                                </button>
                                <button
                                  onClick={() => openShareModal(file.id, file.original_name, "file", file.public_token)}
                                  className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                                  title="Share"
                                >
                                  <Share2 className="h-4 w-4" />
                                </button>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleDeleteFile(file.id);
                                  }}
                                  className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                                  title="Delete"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
              </tbody>
            </table>
            
            {(folderTotal > ITEMS_PER_PAGE || fileTotal > ITEMS_PER_PAGE) && (
              <div className="bg-slate-50 border-t border-slate-200 p-6 space-y-6">
                {folderTotal > ITEMS_PER_PAGE && (
                  <div className="flex flex-col space-y-3">
                    <div className="flex items-center space-x-2 px-2">
                      <div className="h-1 w-1 bg-indigo-600 rounded-full" />
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Folder Navigation</span>
                    </div>
                    <Pagination
                      currentPage={folderPage}
                      totalItems={folderTotal}
                      itemsPerPage={ITEMS_PER_PAGE}
                      onPageChange={setFolderPage}
                    />
                  </div>
                )}
                {fileTotal > ITEMS_PER_PAGE && (
                  <div className="flex flex-col space-y-3">
                    <div className="flex items-center space-x-2 px-2">
                      <div className="h-1 w-1 bg-indigo-600 rounded-full" />
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">File Navigation</span>
                    </div>
                    <Pagination
                      currentPage={filePage}
                      totalItems={fileTotal}
                      itemsPerPage={ITEMS_PER_PAGE}
                      onPageChange={setFilePage}
                    />
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Create Folder Modal */}
      <AnimatePresence>
        {isCreateFolderOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCreateFolderOpen(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 overflow-hidden"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-900">Create New Folder</h3>
                <button
                  onClick={() => setIsCreateFolderOpen(false)}
                  className="p-2 text-slate-400 hover:text-slate-600 rounded-full transition-colors"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <form onSubmit={handleCreateFolder}>
                <div className="mb-6">
                  <label className="block text-sm font-medium text-slate-700 mb-2">Folder Name</label>
                  <div className="relative">
                    <Folder className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                    <input
                      type="text"
                      autoFocus
                      required
                      value={newFolderName}
                      onChange={(e) => setNewFolderName(e.target.value)}
                      className="block w-full pl-10 pr-4 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-slate-900"
                      placeholder="Enter folder name..."
                    />
                  </div>
                </div>

                <div className="mb-6">
                  <label className="block text-sm font-medium text-slate-700 mb-2">Folder Password (Optional)</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                    <input
                      type="password"
                      value={newFolderPassword}
                      onChange={(e) => setNewFolderPassword(e.target.value)}
                      className="block w-full pl-10 pr-4 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-slate-900"
                      placeholder="Set a password to lock this folder..."
                    />
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">If you set a password, it will be required every time the folder is opened.</p>
                </div>

                <div className="flex space-x-3">
                  <button
                    type="button"
                    onClick={() => setIsCreateFolderOpen(false)}
                    className="flex-1 px-4 py-3 border border-slate-200 text-slate-700 font-semibold rounded-xl hover:bg-slate-50 transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 px-4 py-3 bg-indigo-600 text-white font-semibold rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
                  >
                    Create Folder
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Rename Modal */}
      <AnimatePresence>
        {isRenameOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsRenameOpen(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 overflow-hidden"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-900">Rename {renameTarget?.type}</h3>
                <button
                  onClick={() => setIsRenameOpen(false)}
                  className="p-2 text-slate-400 hover:text-slate-600 rounded-full transition-colors"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <form onSubmit={handleRename}>
                <div className="mb-6">
                  <label className="block text-sm font-medium text-slate-700 mb-2">New Name</label>
                  <input
                    type="text"
                    autoFocus
                    required
                    value={renameValue}
                    onChange={(e) => setRenameValue(e.target.value)}
                    className="block w-full px-4 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-slate-900"
                    placeholder="Enter new name..."
                  />
                </div>

                <div className="flex space-x-3">
                  <button
                    type="button"
                    onClick={() => setIsRenameOpen(false)}
                    className="flex-1 px-4 py-3 border border-slate-200 text-slate-700 font-semibold rounded-xl hover:bg-slate-50 transition-all"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 px-4 py-3 bg-indigo-600 text-white font-semibold rounded-xl hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100"
                  >
                    Save Changes
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <ConfirmModal
        isOpen={confirmConfig.isOpen}
        onClose={() => {
          console.log("Dashboard: Closing ConfirmModal");
          setConfirmConfig(prev => ({ ...prev, isOpen: false }));
        }}
        onConfirm={confirmConfig.onConfirm}
        title={confirmConfig.title}
        message={confirmConfig.message}
      />

      {shareItem && (
        <ShareModal
          isOpen={isShareModalOpen}
          onClose={() => setIsShareModalOpen(false)}
          item={shareItem}
        />
      )}
    </div>
  );
};

export default Dashboard;
