import React from "react";
import { motion } from "motion/react";
import { FolderOpen, Zap, Users } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useTranslation } from "react-i18next";

const Home: React.FC = () => {
  const { user } = useAuth();
  const { t } = useTranslation();

  return (
    <div className="bg-slate-50/50 overflow-hidden min-h-screen">
      {/* Hero Section */}
      <section className="relative pt-20 pb-24 lg:pt-32 lg:pb-40 overflow-hidden">
        {/* Background Decorations */}
        <div className="absolute inset-0 -z-10">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full max-w-7xl">
            <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-100/40 rounded-full blur-[120px] animate-pulse" />
            <div className="absolute bottom-[10%] right-[-5%] w-[30%] h-[30%] bg-blue-100/30 rounded-full blur-[100px]" />
          </div>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center text-center max-w-4xl mx-auto">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-5xl font-black tracking-tight text-slate-900 sm:text-6xl md:text-7xl leading-[1.05]"
            >
              {!t('home.heroSubtitle') ? (
                <span className="block bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 via-blue-600 to-indigo-500">
                  {t('home.heroTitle')}
                </span>
              ) : (
                <>
                  <span className="block">{t('home.heroTitle')}</span>
                  <span className="block bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 via-blue-600 to-indigo-500">
                    {t('home.heroSubtitle')}
                  </span>
                </>
              )}
            </motion.h1>

            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="mt-8 text-lg text-slate-600 sm:text-xl leading-relaxed max-w-2xl font-medium"
            >
              {t('home.heroDescription')}
            </motion.p>

            {/* Removed Buttons as requested */}
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.4, duration: 0.8 }}
              className="mt-20 relative w-full max-w-5xl"
            >
              <div className="absolute -inset-4 bg-gradient-to-r from-indigo-500/10 to-blue-500/10 rounded-[2.5rem] blur-2xl" />
              <div className="relative bg-white p-2 rounded-[2rem] shadow-[0_32px_64px_-12px_rgba(0,0,0,0.08)] border border-slate-100">
                <div className="rounded-[1.5rem] overflow-hidden border border-slate-50">
                  <img
                    className="w-full object-cover aspect-[16/9] lg:aspect-[21/9]"
                    src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=1600&h=900"
                    alt="Advanced Document Management System"
                    referrerPolicy="no-referrer"
                  />
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-32 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-20">
            <div className="max-w-2xl">
              <h2 className="text-sm font-bold text-indigo-600 uppercase tracking-[0.2em] mb-4">
                {t('home.features')}
              </h2>
              <p className="text-4xl font-bold text-slate-900 sm:text-5xl tracking-tight">
                {t('home.featuresTitle')}
              </p>
            </div>
            <div className="hidden md:block h-px flex-1 bg-slate-200 mx-8 mb-6" />
          </div>

          <div className="grid grid-cols-1 gap-10 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                icon: FolderOpen,
                title: t('home.orgTitle'),
                desc: t('home.orgDesc'),
                color: "indigo"
              },
              {
                icon: Users,
                title: t('home.roleTitle'),
                desc: t('home.roleDesc'),
                color: "blue"
              },
              {
                icon: Zap,
                title: t('home.fastTitle'),
                desc: t('home.fastDesc'),
                color: "amber"
              }
            ].map((feature, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="group relative bg-white p-8 rounded-3xl border border-slate-100 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300"
              >
                <div className={`inline-flex items-center justify-center p-4 bg-${feature.color}-50 rounded-2xl mb-8 group-hover:scale-110 transition-transform duration-300`}>
                  <feature.icon className={`h-7 w-7 text-${feature.color}-600`} />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-4">{feature.title}</h3>
                <p className="text-slate-500 leading-relaxed">
                  {feature.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust / Stats Section */}
      <section className="py-24 border-t border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-12 text-center">
            {[
              { label: "Active Users", value: "10k+" },
              { label: "Files Secured", value: "1M+" },
              { label: "Uptime", value: "99.9%" },
              { label: "Support", value: "24/7" }
            ].map((stat, idx) => (
              <div key={idx}>
                <p className="text-3xl font-black text-slate-900 mb-1">{stat.value}</p>
                <p className="text-sm font-medium text-slate-500 uppercase tracking-wider">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
