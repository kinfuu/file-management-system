import React from "react";
import { motion } from "motion/react";
import { Users, Target, Shield, Award } from "lucide-react";

const About: React.FC = () => {
  return (
    <div className="bg-white py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl lg:text-center">
          <motion.h2 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-base font-semibold leading-7 text-indigo-600"
          >
            About Us
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mt-2 text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl"
          >
            Empowering teams through secure data management
          </motion.p>
          <motion.p 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mt-6 text-lg leading-8 text-slate-600"
          >
            Secure FMS was founded with a simple mission: to make professional-grade file management 
            accessible to organizations of all sizes. We believe that security shouldn't come at the 
            expense of usability.
          </motion.p>
        </div>

        <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-none">
          <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-16 lg:max-w-none lg:grid-cols-3">
            <div className="flex flex-col">
              <dt className="flex items-center gap-x-3 text-base font-semibold leading-7 text-slate-900">
                <Target className="h-5 w-5 flex-none text-indigo-600" aria-hidden="true" />
                Our Mission
              </dt>
              <dd className="mt-4 flex flex-auto flex-col text-base leading-7 text-slate-600">
                <p className="flex-auto">To provide the most secure and intuitive file management experience for modern enterprises.</p>
              </dd>
            </div>
            <div className="flex flex-col">
              <dt className="flex items-center gap-x-3 text-base font-semibold leading-7 text-slate-900">
                <Shield className="h-5 w-5 flex-none text-indigo-600" aria-hidden="true" />
                Our Values
              </dt>
              <dd className="mt-4 flex flex-auto flex-col text-base leading-7 text-slate-600">
                <p className="flex-auto">Security first, user-centric design, and uncompromising integrity in everything we build.</p>
              </dd>
            </div>
            <div className="flex flex-col">
              <dt className="flex items-center gap-x-3 text-base font-semibold leading-7 text-slate-900">
                <Users className="h-5 w-5 flex-none text-indigo-600" aria-hidden="true" />
                Our Team
              </dt>
              <dd className="mt-4 flex flex-auto flex-col text-base leading-7 text-slate-600">
                <p className="flex-auto">A diverse group of security experts and designers dedicated to solving complex data challenges.</p>
              </dd>
            </div>
          </dl>
        </div>
      </div>
    </div>
  );
};

export default About;
