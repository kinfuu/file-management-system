import React, { useState } from "react";
import { motion } from "motion/react";
import { Mail, Phone, MapPin, Send, CheckCircle, Facebook, MessageCircle } from "lucide-react";

const Contact: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="bg-white py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">Get in touch</h2>
          <p className="mt-2 text-lg leading-8 text-slate-600">
            Have questions about Secure FMS? Our team is here to help.
          </p>
        </div>
        <div className="mx-auto mt-16 grid max-w-4xl grid-cols-1 gap-12 lg:grid-cols-2">
          <div className="space-y-8">
            <div className="flex gap-x-4">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-indigo-600">
                <Mail className="h-6 w-6 text-white" aria-hidden="true" />
              </div>
              <div>
                <h3 className="text-base font-semibold leading-7 text-slate-900">Email</h3>
                <p className="mt-2 leading-7 text-slate-600">yobsan46@gmail.com</p>
              </div>
            </div>
            <div className="flex gap-x-4">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-indigo-600">
                <Phone className="h-6 w-6 text-white" aria-hidden="true" />
              </div>
              <div>
                <h3 className="text-base font-semibold leading-7 text-slate-900">Phone</h3>
                <p className="mt-2 leading-7 text-slate-600">+215925020855</p>
              </div>
            </div>
            <div className="flex gap-x-4">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-indigo-600">
                <MapPin className="h-6 w-6 text-white" aria-hidden="true" />
              </div>
              <div>
                <h3 className="text-base font-semibold leading-7 text-slate-900">Office</h3>
                <p className="mt-2 leading-7 text-slate-600">
                  Addis Ababa
                </p>
              </div>
            </div>

            <div className="pt-8 border-t border-slate-100">
              <h3 className="text-base font-semibold leading-7 text-slate-900 mb-4">Social Media</h3>
              <div className="flex space-x-6">
                <a 
                  href="https://facebook.com/yobsan46" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="flex items-center space-x-2 text-slate-600 hover:text-indigo-600 transition-colors"
                >
                  <Facebook className="h-5 w-5" />
                  <span className="text-sm">Facebook</span>
                </a>
                <a 
                  href="https://t.me/yobsan46" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="flex items-center space-x-2 text-slate-600 hover:text-indigo-600 transition-colors"
                >
                  <Send className="h-5 w-5" />
                  <span className="text-sm">Telegram</span>
                </a>
                <a 
                  href="https://wa.me/215925020855" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="flex items-center space-x-2 text-slate-600 hover:text-indigo-600 transition-colors"
                >
                  <MessageCircle className="h-5 w-5" />
                  <span className="text-sm">WhatsApp</span>
                </a>
              </div>
            </div>
          </div>

          <div className="bg-slate-50 p-8 rounded-2xl border border-slate-100 shadow-sm">
            {submitted ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-12"
              >
                <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-slate-900">Message Sent!</h3>
                <p className="text-slate-600 mt-2">We'll get back to you as soon as possible.</p>
                <button 
                  onClick={() => setSubmitted(false)}
                  className="mt-6 text-indigo-600 font-semibold hover:text-indigo-500"
                >
                  Send another message
                </button>
              </motion.div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-semibold leading-6 text-slate-900">Name</label>
                  <input
                    type="text"
                    name="name"
                    id="name"
                    required
                    className="mt-2.5 block w-full rounded-xl border border-slate-200 px-3.5 py-2 text-slate-900 shadow-sm ring-1 ring-inset ring-slate-300 placeholder:text-slate-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-semibold leading-6 text-slate-900">Email</label>
                  <input
                    type="email"
                    name="email"
                    id="email"
                    required
                    placeholder="yourname@gmail.com"
                    className="mt-2.5 block w-full rounded-xl border border-slate-200 px-3.5 py-2 text-slate-900 shadow-sm ring-1 ring-inset ring-slate-300 placeholder:text-slate-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                  />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-semibold leading-6 text-slate-900">Message</label>
                  <textarea
                    name="message"
                    id="message"
                    rows={4}
                    required
                    className="mt-2.5 block w-full rounded-xl border border-slate-200 px-3.5 py-2 text-slate-900 shadow-sm ring-1 ring-inset ring-slate-300 placeholder:text-slate-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                  ></textarea>
                </div>
                <button
                  type="submit"
                  className="w-full rounded-xl bg-indigo-600 px-3.5 py-2.5 text-center text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 transition-all flex items-center justify-center gap-2"
                >
                  <Send className="h-4 w-4" />
                  Send Message
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
